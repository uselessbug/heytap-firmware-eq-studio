00147000 1016f000 68b9       cbnz         r0, #0x1016f01e
00147002 1016f002 0e48       ldr          r0, [pc, #0x38] ; literal raw=0x14703c: 0x1016efa9
00147004 1016f004 0cf0acfa   bl           #0x1017b560
00147008 1016f008 0d49       ldr          r1, [pc, #0x34] ; literal raw=0x147040: 0x10787880 Start to rx cp_subsys trace
0014700a 1016f00a 4020       movs         r0, #0x40
0014700c 1016f00c 03b0       add          sp, #0xc
0014700e 1016f00e bde83040   pop.w        {r4, r5, lr}
00147012 1016f012 d1f779b9   b.w          #0x10140308
00147016 1016f016 0146       mov          r1, r0
00147018 1016f018 0a48       ldr          r0, [pc, #0x28] ; literal raw=0x147044: 0x10787818 hal_rmt_ipc_open failed: %d
0014701a 1016f01a d1f721fc   bl           #0x10140860
0014701e 1016f01e 0146       mov          r1, r0
00147020 1016f020 0948       ldr          r0, [pc, #0x24] ; literal raw=0x147048: 0x10787834 hal_rmt_ipc_start_recv failed: %d
00147022 1016f022 d1f71dfc   bl           #0x10140860
00147026 1016f026 00bf       nop          
00147028 1016f028 140f       lsrs         r4, r2, #0x1c
0014702a 1016f02a 2420       movs         r0, #0x24
0014702c 1016f02c b5ef1610   vshr.s32     d1, d6, #0xb
00147030 1016f030 100f       lsrs         r0, r2, #0x1c
00147032 1016f032 2420       movs         r0, #0x24
00147034 1016f034 7878       ldrb         r0, [r7, #1]
00147036 1016f036 7810       asrs         r0, r7, #1
00147038 1016f038 99ef1610   vshr.s16     d1, d6, #7
0014703c 1016f03c a9ef1610   vshr.s32     d1, d6, #0x17
00147040 1016f040 8078       ldrb         r0, [r0, #2]
00147042 1016f042 7810       asrs         r0, r7, #1
00147044 1016f044 1878       ldrb         r0, [r3]
00147046 1016f046 7810       asrs         r0, r7, #1
00147048 1016f048 3478       ldrb         r4, [r6]
0014704a 1016f04a 7810       asrs         r0, r7, #1
0014704c 1016f04c 10b5       push         {r4, lr}
0014704e 1016f04e 084c       ldr          r4, [pc, #0x20] ; literal raw=0x147070: 0x20240f10
00147050 1016f050 0848       ldr          r0, [pc, #0x20] ; literal raw=0x147074: 0x1016efa9
00147052 1016f052 0cf09dfa   bl           #0x1017b590
00147056 1016f056 2068       ldr          r0, [r4]
00147058 1016f058 d4f76cf9   bl           #0x10143334
0014705c 1016f05c 2068       ldr          r0, [r4]
0014705e 1016f05e d4f78df8   bl           #0x1014317c
00147062 1016f062 0549       ldr          r1, [pc, #0x14] ; literal raw=0x147078: 0x1078789c Stop rx cp_subsys trace
00147064 1016f064 4020       movs         r0, #0x40
00147066 1016f066 bde81040   pop.w        {r4, lr}
0014706a 1016f06a d1f74db9   b.w          #0x10140308
0014706e 1016f06e 00bf       nop          
00147070 1016f070 100f       lsrs         r0, r2, #0x1c
00147072 1016f072 2420       movs         r0, #0x24
00147074 1016f074 a9ef1610   vshr.s32     d1, d6, #0x17
00147078 1016f078 9c78       ldrb         r4, [r3, #2]
0014707a 1016f07a 7810       asrs         r0, r7, #1
0014707c 1016f07c 0346       mov          r3, r0
0014707e 1016f07e 0a46       mov          r2, r1
00147080 1016f080 0148       ldr          r0, [pc, #4] ; literal raw=0x147088: 0x20240f34
00147082 1016f082 1946       mov          r1, r3
00147084 1016f084 0cf0eeb9   b.w          #0x1017b464
00147088 1016f088 340f       lsrs         r4, r6, #0x1c
0014708a 1016f08a 2420       movs         r0, #0x24
0014708c 1016f08c 0148       ldr          r0, [pc, #4] ; literal raw=0x147094: 0x20240f34
0014708e 1016f08e 0cf01dba   b.w          #0x1017b4cc
00147092 1016f092 00bf       nop          
00147094 1016f094 340f       lsrs         r4, r6, #0x1c
00147096 1016f096 2420       movs         r0, #0x24
00147098 1016f098 10b4       push         {r4}
0014709a 1016f09a 044c       ldr          r4, [pc, #0x10] ; literal raw=0x1470ac: 0x20240f30
0014709c 1016f09c 1346       mov          r3, r2
0014709e 1016f09e 0a46       mov          r2, r1
001470a0 1016f0a0 0146       mov          r1, r0
001470a2 1016f0a2 2068       ldr          r0, [r4]
001470a4 1016f0a4 5df8044b   ldr          r4, [sp], #4
001470a8 1016f0a8 d4f76ab9   b.w          #0x10143380
001470ac 1016f0ac 300f       lsrs         r0, r6, #0x1c
001470ae 1016f0ae 2420       movs         r0, #0x24
001470b0 1016f0b0 30b5       push         {r4, r5, lr}
001470b2 1016f0b2 164a       ldr          r2, [pc, #0x58] ; literal raw=0x14710c: 0x20240f34
001470b4 1016f0b4 0023       movs         r3, #0
001470b6 1016f0b6 83b0       sub          sp, #0xc
001470b8 1016f0b8 1548       ldr          r0, [pc, #0x54] ; literal raw=0x147110: 0x1016f099
001470ba 1016f0ba 0121       movs         r1, #1
001470bc 1016f0bc 154c       ldr          r4, [pc, #0x54] ; literal raw=0x147114: 0x20240f30
001470be 1016f0be 164d       ldr          r5, [pc, #0x58] ; literal raw=0x147118: 0x107878b4 CP1_S
001470c0 1016f0c0 cde90034   strd         r3, r4, [sp]
001470c4 1016f0c4 1361       str          r3, [r2, #0x10]
001470c6 1016f0c6 5061       str          r0, [r2, #0x14]
001470c8 1016f0c8 0220       movs         r0, #2
001470ca 1016f0ca 1560       str          r5, [r2]
001470cc 1016f0cc 5360       str          r3, [r2, #4]
001470ce 1016f0ce 1174       strb         r1, [r2, #0x10]
001470d0 1016f0d0 9361       str          r3, [r2, #0x18]
001470d2 1016f0d2 c2e90233   strd         r3, r3, [r2, #8]
001470d6 1016f0d6 114a       ldr          r2, [pc, #0x44] ; literal raw=0x14711c: 0x1016f07d
001470d8 1016f0d8 d3f7b6fd   bl           #0x10142c48
001470dc 1016f0dc 68b9       cbnz         r0, #0x1016f0fa
001470de 1016f0de 2068       ldr          r0, [r4]
001470e0 1016f0e0 d4f7daf8   bl           #0x10143298
001470e4 1016f0e4 68b9       cbnz         r0, #0x1016f102
001470e6 1016f0e6 0e48       ldr          r0, [pc, #0x38] ; literal raw=0x147120: 0x1016f08d
001470e8 1016f0e8 0cf03afa   bl           #0x1017b560
001470ec 1016f0ec 0d49       ldr          r1, [pc, #0x34] ; literal raw=0x147124: 0x107878bc Start to rx cp_subsys1 trace
001470ee 1016f0ee 4020       movs         r0, #0x40
001470f0 1016f0f0 03b0       add          sp, #0xc
001470f2 1016f0f2 bde83040   pop.w        {r4, r5, lr}
001470f6 1016f0f6 d1f707b9   b.w          #0x10140308
001470fa 1016f0fa 0146       mov          r1, r0
001470fc 1016f0fc 0a48       ldr          r0, [pc, #0x28] ; literal raw=0x147128: 0x10787818 hal_rmt_ipc_open failed: %d
001470fe 1016f0fe d1f7affb   bl           #0x10140860
00147102 1016f102 0146       mov          r1, r0
00147104 1016f104 0948       ldr          r0, [pc, #0x24] ; literal raw=0x14712c: 0x10787834 hal_rmt_ipc_start_recv failed: %d
00147106 1016f106 d1f7abfb   bl           #0x10140860
0014710a 1016f10a 00bf       nop          
0014710c 1016f10c 340f       lsrs         r4, r6, #0x1c
0014710e 1016f10e 2420       movs         r0, #0x24
00147110 1016f110 99f01610   eors         r0, sb, #0x160016
00147114 1016f114 300f       lsrs         r0, r6, #0x1c
00147116 1016f116 2420       movs         r0, #0x24
00147118 1016f118 b478       ldrb         r4, [r6, #2]
0014711a 1016f11a 7810       asrs         r0, r7, #1
0014711c 1016f11c 7df01610   orns         r0, sp, #0x160016
00147120 1016f120 8df01610   eor          r0, sp, #0x160016
00147124 1016f124 bc78       ldrb         r4, [r7, #2]
00147126 1016f126 7810       asrs         r0, r7, #1
00147128 1016f128 1878       ldrb         r0, [r3]
0014712a 1016f12a 7810       asrs         r0, r7, #1
0014712c 1016f12c 3478       ldrb         r4, [r6]
0014712e 1016f12e 7810       asrs         r0, r7, #1
00147130 1016f130 10b5       push         {r4, lr}
00147132 1016f132 084c       ldr          r4, [pc, #0x20] ; literal raw=0x147154: 0x20240f30
00147134 1016f134 0848       ldr          r0, [pc, #0x20] ; literal raw=0x147158: 0x1016f08d
00147136 1016f136 0cf02bfa   bl           #0x1017b590
0014713a 1016f13a 2068       ldr          r0, [r4]
0014713c 1016f13c d4f7faf8   bl           #0x10143334
00147140 1016f140 2068       ldr          r0, [r4]
00147142 1016f142 d4f71bf8   bl           #0x1014317c
00147146 1016f146 0549       ldr          r1, [pc, #0x14] ; literal raw=0x14715c: 0x107878dc Stop rx cp_subsys1 trace
00147148 1016f148 4020       movs         r0, #0x40
0014714a 1016f14a bde81040   pop.w        {r4, lr}
0014714e 1016f14e d1f7dbb8   b.w          #0x10140308
00147152 1016f152 00bf       nop          
00147154 1016f154 300f       lsrs         r0, r6, #0x1c
00147156 1016f156 2420       movs         r0, #0x24
00147158 1016f158 8df01610   eor          r0, sp, #0x160016
0014715c 1016f15c dc78       ldrb         r4, [r3, #3]
0014715e 1016f15e 7810       asrs         r0, r7, #1
00147160 1016f160 f0b5       push         {r4, r5, r6, r7, lr}
00147162 1016f162 254b       ldr          r3, [pc, #0x94] ; literal raw=0x1471f8: 0x201a0b50
00147164 1016f164 85b0       sub          sp, #0x14
00147166 1016f166 0546       mov          r5, r0
00147168 1016f168 2448       ldr          r0, [pc, #0x90] ; literal raw=0x1471fc: 0x21d7ffa0
0014716a 1016f16a 254f       ldr          r7, [pc, #0x94] ; literal raw=0x147200: 0x30336d38
0014716c 1016f16c 0e46       mov          r6, r1
0014716e 1016f16e 1b68       ldr          r3, [r3]
00147170 1016f170 0393       str          r3, [sp, #0xc]
00147172 1016f172 4ff00003   mov.w        r3, #0
00147176 1016f176 d8f7d7f8   bl           #0x10147328
0014717a 1016f17a 02ab       add          r3, sp, #8
0014717c 1016f17c 2149       ldr          r1, [pc, #0x84] ; literal raw=0x147204: 0x3038c148
0014717e 1016f17e 0022       movs         r2, #0
00147180 1016f180 3846       mov          r0, r7
00147182 1016f182 0093       str          r3, [sp]
00147184 1016f184 c91b       subs         r1, r1, r7
00147186 1016f186 204b       ldr          r3, [pc, #0x80] ; literal raw=0x147208: 0x0010db15
00147188 1016f188 0df09efe   bl           #0x1017cec8
0014718c 1016f18c 0446       mov          r4, r0
0014718e 1016f18e 18bb       cbnz         r0, #0x1016f1d8
00147190 1016f190 3846       mov          r0, r7
00147192 1016f192 1e4f       ldr          r7, [pc, #0x78] ; literal raw=0x14720c: 0x20240f50
00147194 1016f194 1c4a       ldr          r2, [pc, #0x70] ; literal raw=0x147208: 0x0010db15
00147196 1016f196 2146       mov          r1, r4
00147198 1016f198 cbf7ccfe   bl           #0x1013af34
0014719c 1016f19c 3346       mov          r3, r6
0014719e 1016f19e 2a46       mov          r2, r5
001471a0 1016f1a0 2146       mov          r1, r4
001471a2 1016f1a2 0220       movs         r0, #2
001471a4 1016f1a4 cde90047   strd         r4, r7, [sp]
001471a8 1016f1a8 d3f74efd   bl           #0x10142c48
001471ac 1016f1ac f8b9       cbnz         r0, #0x1016f1ee
001471ae 1016f1ae fff77fff   bl           #0x1016f0b0
001471b2 1016f1b2 3868       ldr          r0, [r7]
001471b4 1016f1b4 d4f770f8   bl           #0x10143298
001471b8 1016f1b8 0446       mov          r4, r0
001471ba 1016f1ba a0b9       cbnz         r0, #0x1016f1e6
001471bc 1016f1bc 0299       ldr          r1, [sp, #8]
001471be 1016f1be 0f48       ldr          r0, [pc, #0x3c] ; literal raw=0x1471fc: 0x21d7ffa0
001471c0 1016f1c0 d8f7fcf8   bl           #0x101473bc
001471c4 1016f1c4 0c4b       ldr          r3, [pc, #0x30] ; literal raw=0x1471f8: 0x201a0b50
001471c6 1016f1c6 1a68       ldr          r2, [r3]
001471c8 1016f1c8 039b       ldr          r3, [sp, #0xc]
001471ca 1016f1ca 5a40       eors         r2, r3
001471cc 1016f1cc 4ff00003   mov.w        r3, #0
001471d0 1016f1d0 07d1       bne          #0x1016f1e2
001471d2 1016f1d2 2046       mov          r0, r4
001471d4 1016f1d4 05b0       add          sp, #0x14
001471d6 1016f1d6 f0bd       pop          {r4, r5, r6, r7, pc}
001471d8 1016f1d8 0246       mov          r2, r0
001471da 1016f1da 0d49       ldr          r1, [pc, #0x34] ; literal raw=0x147210: 0x1078790c cp_subsys1_open
001471dc 1016f1dc 0d48       ldr          r0, [pc, #0x34] ; literal raw=0x147214: 0x107877f4 %s: Failed to load subsys image: %d
001471de 1016f1de d1f73ffb   bl           #0x10140860
001471e2 1016f1e2 0df093fa   bl           #0x1017c70c
001471e6 1016f1e6 0146       mov          r1, r0
001471e8 1016f1e8 0b48       ldr          r0, [pc, #0x2c] ; literal raw=0x147218: 0x10787834 hal_rmt_ipc_start_recv failed: %d
001471ea 1016f1ea d1f739fb   bl           #0x10140860
001471ee 1016f1ee 0146       mov          r1, r0
001471f0 1016f1f0 0a48       ldr          r0, [pc, #0x28] ; literal raw=0x14721c: 0x10787818 hal_rmt_ipc_open failed: %d
001471f2 1016f1f2 d1f735fb   bl           #0x10140860
001471f6 1016f1f6 00bf       nop          
001471f8 1016f1f8 500b       lsrs         r0, r2, #0xd
001471fa 1016f1fa 1a20       movs         r0, #0x1a
001471fc 1016f1fc a0ff       .byte        0xa0, 0xff
001471fe 1016f1fe d721       movs         r1, #0xd7
00147200 1016f200 386d       ldr          r0, [r7, #0x50]
00147202 1016f202 3330       adds         r0, #0x33
00147204 1016f204 48c1       stm          r1!, {r3, r6}
00147206 1016f206 3830       adds         r0, #0x38
00147208 1016f208 15db       blt          #0x1016f236
0014720a 1016f20a 1000       movs         r0, r2
0014720c 1016f20c 500f       lsrs         r0, r2, #0x1d
0014720e 1016f20e 2420       movs         r0, #0x24
00147210 1016f210 0c79       ldrb         r4, [r1, #4]
00147212 1016f212 7810       asrs         r0, r7, #1
00147214 1016f214 f477       strb         r4, [r6, #0x1f]
00147216 1016f216 7810       asrs         r0, r7, #1
00147218 1016f218 3478       ldrb         r4, [r6]
0014721a 1016f21a 7810       asrs         r0, r7, #1
0014721c 1016f21c 1878       ldrb         r0, [r3]
0014721e 1016f21e 7810       asrs         r0, r7, #1
00147220 1016f220 08b5       push         {r3, lr}
00147222 1016f222 074a       ldr          r2, [pc, #0x1c] ; literal raw=0x147240: 0x107878f8 cp_subsys1_close
00147224 1016f224 4120       movs         r0, #0x41
00147226 1016f226 0749       ldr          r1, [pc, #0x1c] ; literal raw=0x147244: 0x107dcf2c %s
00147228 1016f228 d1f76ef8   bl           #0x10140308
0014722c 1016f22c fff780ff   bl           #0x1016f130
00147230 1016f230 054b       ldr          r3, [pc, #0x14] ; literal raw=0x147248: 0x20240f50
00147232 1016f232 1868       ldr          r0, [r3]
00147234 1016f234 d3f7a2ff   bl           #0x1014317c
00147238 1016f238 d8f786f8   bl           #0x10147348
0014723c 1016f23c 0020       movs         r0, #0
0014723e 1016f23e 08bd       pop          {r3, pc}
00147240 1016f240 f878       ldrb         r0, [r7, #3]
00147242 1016f242 7810       asrs         r0, r7, #1
00147244 1016f244 2ccf       ldm          r7!, {r2, r3, r5}
00147246 1016f246 7d10       asrs         r5, r7, #1
00147248 1016f248 500f       lsrs         r0, r2, #0x1d
0014724a 1016f24a 2420       movs         r0, #0x24
0014724c 1016f24c 024b       ldr          r3, [pc, #8] ; literal raw=0x147258: 0x20240f50
0014724e 1016f24e 0a46       mov          r2, r1
00147250 1016f250 0146       mov          r1, r0
00147252 1016f252 1868       ldr          r0, [r3]
00147254 1016f254 d4f796b8   b.w          #0x10143384
00147258 1016f258 500f       lsrs         r0, r2, #0x1d
0014725a 1016f25a 2420       movs         r0, #0x24
0014725c 1016f25c 0346       mov          r3, r0
0014725e 1016f25e 0a46       mov          r2, r1
00147260 1016f260 0148       ldr          r0, [pc, #4] ; literal raw=0x147268: 0x20240f58
00147262 1016f262 1946       mov          r1, r3
00147264 1016f264 0cf0feb8   b.w          #0x1017b464
00147268 1016f268 580f       lsrs         r0, r3, #0x1d
0014726a 1016f26a 2420       movs         r0, #0x24
0014726c 1016f26c 0148       ldr          r0, [pc, #4] ; literal raw=0x147274: 0x20240f58
0014726e 1016f26e 0cf02db9   b.w          #0x1017b4cc
00147272 1016f272 00bf       nop          
00147274 1016f274 580f       lsrs         r0, r3, #0x1d
00147276 1016f276 2420       movs         r0, #0x24
00147278 1016f278 10b4       push         {r4}
0014727a 1016f27a 044c       ldr          r4, [pc, #0x10] ; literal raw=0x14728c: 0x20240f54
0014727c 1016f27c 1346       mov          r3, r2
0014727e 1016f27e 0a46       mov          r2, r1
00147280 1016f280 0146       mov          r1, r0
00147282 1016f282 2068       ldr          r0, [r4]
00147284 1016f284 5df8044b   ldr          r4, [sp], #4
00147288 1016f288 d4f77ab8   b.w          #0x10143380
0014728c 1016f28c 540f       lsrs         r4, r2, #0x1d
0014728e 1016f28e 2420       movs         r0, #0x24
00147290 1016f290 30b5       push         {r4, r5, lr}
00147292 1016f292 164a       ldr          r2, [pc, #0x58] ; literal raw=0x1472ec: 0x20240f58
00147294 1016f294 0023       movs         r3, #0
00147296 1016f296 83b0       sub          sp, #0xc
00147298 1016f298 1548       ldr          r0, [pc, #0x54] ; literal raw=0x1472f0: 0x1016f279
0014729a 1016f29a 0121       movs         r1, #1
0014729c 1016f29c 154c       ldr          r4, [pc, #0x54] ; literal raw=0x1472f4: 0x20240f54
0014729e 1016f29e 164d       ldr          r5, [pc, #0x58] ; literal raw=0x1472f8: 0x1078791c CP2_S
001472a0 1016f2a0 cde90034   strd         r3, r4, [sp]
001472a4 1016f2a4 1361       str          r3, [r2, #0x10]
001472a6 1016f2a6 5061       str          r0, [r2, #0x14]
001472a8 1016f2a8 0320       movs         r0, #3
001472aa 1016f2aa 1560       str          r5, [r2]
001472ac 1016f2ac 5360       str          r3, [r2, #4]
001472ae 1016f2ae 1174       strb         r1, [r2, #0x10]
001472b0 1016f2b0 9361       str          r3, [r2, #0x18]
001472b2 1016f2b2 c2e90233   strd         r3, r3, [r2, #8]
001472b6 1016f2b6 114a       ldr          r2, [pc, #0x44] ; literal raw=0x1472fc: 0x1016f25d
001472b8 1016f2b8 d3f7c6fc   bl           #0x10142c48
001472bc 1016f2bc 68b9       cbnz         r0, #0x1016f2da
001472be 1016f2be 2068       ldr          r0, [r4]
001472c0 1016f2c0 d3f7eaff   bl           #0x10143298
001472c4 1016f2c4 68b9       cbnz         r0, #0x1016f2e2
001472c6 1016f2c6 0e48       ldr          r0, [pc, #0x38] ; literal raw=0x147300: 0x1016f26d
001472c8 1016f2c8 0cf04af9   bl           #0x1017b560
001472cc 1016f2cc 0d49       ldr          r1, [pc, #0x34] ; literal raw=0x147304: 0x10787924 Start to rx cp_subsys2 trace
001472ce 1016f2ce 4020       movs         r0, #0x40
001472d0 1016f2d0 03b0       add          sp, #0xc
001472d2 1016f2d2 bde83040   pop.w        {r4, r5, lr}
001472d6 1016f2d6 d1f717b8   b.w          #0x10140308
001472da 1016f2da 0146       mov          r1, r0
001472dc 1016f2dc 0a48       ldr          r0, [pc, #0x28] ; literal raw=0x147308: 0x10787818 hal_rmt_ipc_open failed: %d
001472de 1016f2de d1f7bffa   bl           #0x10140860
001472e2 1016f2e2 0146       mov          r1, r0
001472e4 1016f2e4 0948       ldr          r0, [pc, #0x24] ; literal raw=0x14730c: 0x10787834 hal_rmt_ipc_start_recv failed: %d
001472e6 1016f2e6 d1f7bbfa   bl           #0x10140860
001472ea 1016f2ea 00bf       nop          
001472ec 1016f2ec 580f       lsrs         r0, r3, #0x1d
001472ee 1016f2ee 2420       movs         r0, #0x24
001472f0 1016f2f0 79f2       .byte        0x79, 0xf2
001472f2 1016f2f2 1610       asrs         r6, r2, #0x20
001472f4 1016f2f4 540f       lsrs         r4, r2, #0x1d
001472f6 1016f2f6 2420       movs         r0, #0x24
001472f8 1016f2f8 1c79       ldrb         r4, [r3, #4]
001472fa 1016f2fa 7810       asrs         r0, r7, #1
001472fc 1016f2fc 5df2       .byte        0x5d, 0xf2
001472fe 1016f2fe 1610       asrs         r6, r2, #0x20
00147300 1016f300 6df2       .byte        0x6d, 0xf2
00147302 1016f302 1610       asrs         r6, r2, #0x20
00147304 1016f304 2479       ldrb         r4, [r4, #4]
00147306 1016f306 7810       asrs         r0, r7, #1
00147308 1016f308 1878       ldrb         r0, [r3]
0014730a 1016f30a 7810       asrs         r0, r7, #1
0014730c 1016f30c 3478       ldrb         r4, [r6]
0014730e 1016f30e 7810       asrs         r0, r7, #1
00147310 1016f310 10b5       push         {r4, lr}
00147312 1016f312 084c       ldr          r4, [pc, #0x20] ; literal raw=0x147334: 0x20240f54
00147314 1016f314 0848       ldr          r0, [pc, #0x20] ; literal raw=0x147338: 0x1016f26d
00147316 1016f316 0cf03bf9   bl           #0x1017b590
0014731a 1016f31a 2068       ldr          r0, [r4]
0014731c 1016f31c d4f70af8   bl           #0x10143334
00147320 1016f320 2068       ldr          r0, [r4]
00147322 1016f322 d3f72bff   bl           #0x1014317c
00147326 1016f326 0549       ldr          r1, [pc, #0x14] ; literal raw=0x14733c: 0x10787944 Stop rx cp_subsys2 trace
00147328 1016f328 4020       movs         r0, #0x40
0014732a 1016f32a bde81040   pop.w        {r4, lr}
0014732e 1016f32e d0f7ebbf   b.w          #0x10140308
00147332 1016f332 00bf       nop          
00147334 1016f334 540f       lsrs         r4, r2, #0x1d
00147336 1016f336 2420       movs         r0, #0x24
00147338 1016f338 6df2       .byte        0x6d, 0xf2
0014733a 1016f33a 1610       asrs         r6, r2, #0x20
0014733c 1016f33c 4479       ldrb         r4, [r0, #5]
0014733e 1016f33e 7810       asrs         r0, r7, #1
00147340 1016f340 7047       bx           lr
00147342 1016f342 00bf       nop          
00147344 1016f344 70b5       push         {r4, r5, r6, lr}
00147346 1016f346 154e       ldr          r6, [pc, #0x54] ; literal raw=0x14739c: 0x20240f7c
00147348 1016f348 0546       mov          r5, r0
0014734a 1016f34a 0c46       mov          r4, r1
0014734c 1016f34c 3378       ldrb         r3, [r6]
0014734e 1016f34e 5bb9       cbnz         r3, #0x1016f368
00147350 1016f350 50b1       cbz          r0, #0x1016f368
00147352 1016f352 0229       cmp          r1, #2
00147354 1016f354 08d1       bne          #0x1016f368
00147356 1016f356 0378       ldrb         r3, [r0]
00147358 1016f358 482b       cmp          r3, #0x48
0014735a 1016f35a 14d0       beq          #0x1016f386
0014735c 1016f35c 2146       mov          r1, r4
0014735e 1016f35e 2846       mov          r0, r5
00147360 1016f360 26f0d2ff   bl           #0x10196308
00147364 1016f364 2046       mov          r0, r4
00147366 1016f366 70bd       pop          {r4, r5, r6, pc}
00147368 1016f368 102c       cmp          r4, #0x10
0014736a 1016f36a f7d1       bne          #0x1016f35c
0014736c 1016f36c 2b88       ldrh         r3, [r5]
0014736e 1016f36e 002b       cmp          r3, #0
00147370 1016f370 f4d1       bne          #0x1016f35c
00147372 1016f372 6a68       ldr          r2, [r5, #4]
00147374 1016f374 4120       movs         r0, #0x41
00147376 1016f376 0a49       ldr          r1, [pc, #0x28] ; literal raw=0x1473a0: 0x10787974 CP_SUBSYS2: Req sys freq: %u
00147378 1016f378 d0f7c6ff   bl           #0x10140308
0014737c 1016f37c 2979       ldrb         r1, [r5, #4]
0014737e 1016f37e 0220       movs         r0, #2
00147380 1016f380 daf76efa   bl           #0x10149860
00147384 1016f384 eee7       b            #0x1016f364
00147386 1016f386 4378       ldrb         r3, [r0, #1]
00147388 1016f388 692b       cmp          r3, #0x69
0014738a 1016f38a e7d1       bne          #0x1016f35c
0014738c 1016f38c 0549       ldr          r1, [pc, #0x14] ; literal raw=0x1473a4: 0x10787960 cp_subsys2 alive!
0014738e 1016f38e 4020       movs         r0, #0x40
00147390 1016f390 d0f7baff   bl           #0x10140308
00147394 1016f394 0123       movs         r3, #1
00147396 1016f396 3370       strb         r3, [r6]
00147398 1016f398 e4e7       b            #0x1016f364
0014739a 1016f39a 00bf       nop          
0014739c 1016f39c 7c0f       lsrs         r4, r7, #0x1d
0014739e 1016f39e 2420       movs         r0, #0x24
001473a0 1016f3a0 7479       ldrb         r4, [r6, #5]
001473a2 1016f3a2 7810       asrs         r0, r7, #1
001473a4 1016f3a4 6079       ldrb         r0, [r4, #5]
001473a6 1016f3a6 7810       asrs         r0, r7, #1
001473a8 1016f3a8 0228       cmp          r0, #2
001473aa 1016f3aa 10b5       push         {r4, lr}
001473ac 1016f3ac 0446       mov          r4, r0
001473ae 1016f3ae 16d8       bhi          #0x1016f3de
001473b0 1016f3b0 0346       mov          r3, r0
001473b2 1016f3b2 0d4a       ldr          r2, [pc, #0x34] ; literal raw=0x1473e8: 0x107879d8 cp_subsys2_bin_select
001473b4 1016f3b4 0d49       ldr          r1, [pc, #0x34] ; literal raw=0x1473ec: 0x107879a8 %s, id:%d
001473b6 1016f3b6 4220       movs         r0, #0x42
001473b8 1016f3b8 d0f7a6ff   bl           #0x10140308
001473bc 1016f3bc 4cb1       cbz          r4, #0x1016f3d2
001473be 1016f3be 012c       cmp          r4, #1
001473c0 1016f3c0 0ad0       beq          #0x1016f3d8
001473c2 1016f3c2 0b4a       ldr          r2, [pc, #0x2c] ; literal raw=0x1473f0: 0x304fd638
001473c4 1016f3c4 0b4b       ldr          r3, [pc, #0x2c] ; literal raw=0x1473f4: 0x30592c14
001473c6 1016f3c6 0c48       ldr          r0, [pc, #0x30] ; literal raw=0x1473f8: 0x20240f74
001473c8 1016f3c8 9b1a       subs         r3, r3, r2
001473ca 1016f3ca 0c49       ldr          r1, [pc, #0x30] ; literal raw=0x1473fc: 0x20240f78
001473cc 1016f3cc 0260       str          r2, [r0]
001473ce 1016f3ce 0b60       str          r3, [r1]
001473d0 1016f3d0 10bd       pop          {r4, pc}
001473d2 1016f3d2 0b4a       ldr          r2, [pc, #0x2c] ; literal raw=0x147400: 0x3038c148
001473d4 1016f3d4 0b4b       ldr          r3, [pc, #0x2c] ; literal raw=0x147404: 0x304592c0
001473d6 1016f3d6 f6e7       b            #0x1016f3c6
001473d8 1016f3d8 0b4a       ldr          r2, [pc, #0x2c] ; literal raw=0x147408: 0x304592c0
001473da 1016f3da 0c4b       ldr          r3, [pc, #0x30] ; literal raw=0x14740c: 0x304fd638
001473dc 1016f3dc f3e7       b            #0x1016f3c6
001473de 1016f3de 0246       mov          r2, r0
001473e0 1016f3e0 0149       ldr          r1, [pc, #4] ; literal raw=0x1473e8: 0x107879d8 cp_subsys2_bin_select
001473e2 1016f3e2 0b48       ldr          r0, [pc, #0x2c] ; literal raw=0x147410: 0x10787994 %s id:%d is invalid
001473e4 1016f3e4 d1f73cfa   bl           #0x10140860
001473e8 1016f3e8 d879       ldrb         r0, [r3, #7]
001473ea 1016f3ea 7810       asrs         r0, r7, #1
001473ec 1016f3ec a879       ldrb         r0, [r5, #6]
001473ee 1016f3ee 7810       asrs         r0, r7, #1
001473f0 1016f3f0 38d6       bvs          #0x1016f464
001473f2 1016f3f2 4f30       adds         r0, #0x4f
001473f4 1016f3f4 142c       cmp          r4, #0x14
001473f6 1016f3f6 5930       adds         r0, #0x59
001473f8 1016f3f8 740f       lsrs         r4, r6, #0x1d
001473fa 1016f3fa 2420       movs         r0, #0x24
001473fc 1016f3fc 780f       lsrs         r0, r7, #0x1d
001473fe 1016f3fe 2420       movs         r0, #0x24
00147400 1016f400 48c1       stm          r1!, {r3, r6}
00147402 1016f402 3830       adds         r0, #0x38
00147404 1016f404 c092       str          r2, [sp, #0x300]
00147406 1016f406 4530       adds         r0, #0x45
00147408 1016f408 c092       str          r2, [sp, #0x300]
0014740a 1016f40a 4530       adds         r0, #0x45
0014740c 1016f40c 38d6       bvs          #0x1016f480
0014740e 1016f40e 4f30       adds         r0, #0x4f
00147410 1016f410 9479       ldrb         r4, [r2, #6]
00147412 1016f412 7810       asrs         r0, r7, #1
00147414 1016f414 70b5       push         {r4, r5, r6, lr}
00147416 1016f416 284b       ldr          r3, [pc, #0xa0] ; literal raw=0x1474b8: 0x201a0b50
00147418 1016f418 84b0       sub          sp, #0x10
0014741a 1016f41a 0446       mov          r4, r0
0014741c 1016f41c 2748       ldr          r0, [pc, #0x9c] ; literal raw=0x1474bc: 0x2271ffa0
0014741e 1016f41e 1b68       ldr          r3, [r3]
00147420 1016f420 0393       str          r3, [sp, #0xc]
00147422 1016f422 4ff00003   mov.w        r3, #0
00147426 1016f426 0d46       mov          r5, r1
00147428 1016f428 d7f798ff   bl           #0x1014735c
0014742c 1016f42c 2449       ldr          r1, [pc, #0x90] ; literal raw=0x1474c0: 0x20240f74
0014742e 1016f42e 254a       ldr          r2, [pc, #0x94] ; literal raw=0x1474c4: 0x20240f78
00147430 1016f430 02ab       add          r3, sp, #8
00147432 1016f432 0e68       ldr          r6, [r1]
00147434 1016f434 1168       ldr          r1, [r2]
00147436 1016f436 0093       str          r3, [sp]
00147438 1016f438 0023       movs         r3, #0
0014743a 1016f43a 3046       mov          r0, r6
0014743c 1016f43c 1a46       mov          r2, r3
0014743e 1016f43e 0df043fd   bl           #0x1017cec8
00147442 1016f442 0246       mov          r2, r0
00147444 1016f444 48bb       cbnz         r0, #0x1016f49a
00147446 1016f446 0146       mov          r1, r0
00147448 1016f448 3046       mov          r0, r6
0014744a 1016f44a cbf773fd   bl           #0x1013af34
0014744e 1016f44e fcb1       cbz          r4, #0x1016f490
00147450 1016f450 0db3       cbz          r5, #0x1016f496
00147452 1016f452 0021       movs         r1, #0
00147454 1016f454 1c4e       ldr          r6, [pc, #0x70] ; literal raw=0x1474c8: 0x20240f80
00147456 1016f456 2b46       mov          r3, r5
00147458 1016f458 2246       mov          r2, r4
0014745a 1016f45a 0320       movs         r0, #3
0014745c 1016f45c cde90016   strd         r1, r6, [sp]
00147460 1016f460 d3f7f2fb   bl           #0x10142c48
00147464 1016f464 e8b9       cbnz         r0, #0x1016f4a2
00147466 1016f466 fff713ff   bl           #0x1016f290
0014746a 1016f46a 3068       ldr          r0, [r6]
0014746c 1016f46c d3f714ff   bl           #0x10143298
00147470 1016f470 0446       mov          r4, r0
00147472 1016f472 e0b9       cbnz         r0, #0x1016f4ae
00147474 1016f474 0299       ldr          r1, [sp, #8]
00147476 1016f476 1148       ldr          r0, [pc, #0x44] ; literal raw=0x1474bc: 0x2271ffa0
00147478 1016f478 d7f7b6ff   bl           #0x101473e8
0014747c 1016f47c 0e4b       ldr          r3, [pc, #0x38] ; literal raw=0x1474b8: 0x201a0b50
0014747e 1016f47e 1a68       ldr          r2, [r3]
00147480 1016f480 039b       ldr          r3, [sp, #0xc]
00147482 1016f482 5a40       eors         r2, r3
00147484 1016f484 4ff00003   mov.w        r3, #0
00147488 1016f488 0fd1       bne          #0x1016f4aa
0014748a 1016f48a 2046       mov          r0, r4
0014748c 1016f48c 04b0       add          sp, #0x10
0014748e 1016f48e 70bd       pop          {r4, r5, r6, pc}
00147490 1016f490 0e4c       ldr          r4, [pc, #0x38] ; literal raw=0x1474cc: 0x1016f345
00147492 1016f492 002d       cmp          r5, #0
00147494 1016f494 ddd1       bne          #0x1016f452
00147496 1016f496 0e4d       ldr          r5, [pc, #0x38] ; literal raw=0x1474d0: 0x1016f341 G
00147498 1016f498 dbe7       b            #0x1016f452
0014749a 1016f49a 0e49       ldr          r1, [pc, #0x38] ; literal raw=0x1474d4: 0x107879c8 cp_subsys2_open
0014749c 1016f49c 0e48       ldr          r0, [pc, #0x38] ; literal raw=0x1474d8: 0x107877f4 %s: Failed to load subsys image: %d
0014749e 1016f49e d1f7dff9   bl           #0x10140860
001474a2 1016f4a2 0146       mov          r1, r0
001474a4 1016f4a4 0d48       ldr          r0, [pc, #0x34] ; literal raw=0x1474dc: 0x10787818 hal_rmt_ipc_open failed: %d
001474a6 1016f4a6 d1f7dbf9   bl           #0x10140860
001474aa 1016f4aa 0df02ff9   bl           #0x1017c70c
001474ae 1016f4ae 0146       mov          r1, r0
001474b0 1016f4b0 0b48       ldr          r0, [pc, #0x2c] ; literal raw=0x1474e0: 0x10787834 hal_rmt_ipc_start_recv failed: %d
001474b2 1016f4b2 d1f7d5f9   bl           #0x10140860
001474b6 1016f4b6 00bf       nop          
001474b8 1016f4b8 500b       lsrs         r0, r2, #0xd
001474ba 1016f4ba 1a20       movs         r0, #0x1a
001474bc 1016f4bc a0ff       .byte        0xa0, 0xff
001474be 1016f4be 7122       movs         r2, #0x71
001474c0 1016f4c0 740f       lsrs         r4, r6, #0x1d
001474c2 1016f4c2 2420       movs         r0, #0x24
001474c4 1016f4c4 780f       lsrs         r0, r7, #0x1d
001474c6 1016f4c6 2420       movs         r0, #0x24
001474c8 1016f4c8 800f       lsrs         r0, r0, #0x1e
001474ca 1016f4ca 2420       movs         r0, #0x24
001474cc 1016f4cc 45f31610   sbfx         r0, r5, #4, #0x17
001474d0 1016f4d0 41f31610   sbfx         r0, r1, #4, #0x17
001474d4 1016f4d4 c879       ldrb         r0, [r1, #7]
001474d6 1016f4d6 7810       asrs         r0, r7, #1
001474d8 1016f4d8 f477       strb         r4, [r6, #0x1f]
001474da 1016f4da 7810       asrs         r0, r7, #1
001474dc 1016f4dc 1878       ldrb         r0, [r3]
001474de 1016f4de 7810       asrs         r0, r7, #1
001474e0 1016f4e0 3478       ldrb         r4, [r6]
001474e2 1016f4e2 7810       asrs         r0, r7, #1
001474e4 1016f4e4 08b5       push         {r3, lr}
001474e6 1016f4e6 074a       ldr          r2, [pc, #0x1c] ; literal raw=0x147504: 0x107879b4 cp_subsys2_close
001474e8 1016f4e8 4120       movs         r0, #0x41
001474ea 1016f4ea 0749       ldr          r1, [pc, #0x1c] ; literal raw=0x147508: 0x107dcf2c %s
001474ec 1016f4ec d0f70cff   bl           #0x10140308
001474f0 1016f4f0 fff70eff   bl           #0x1016f310
001474f4 1016f4f4 054b       ldr          r3, [pc, #0x14] ; literal raw=0x14750c: 0x20240f80
001474f6 1016f4f6 1868       ldr          r0, [r3]
001474f8 1016f4f8 d3f740fe   bl           #0x1014317c
001474fc 1016f4fc d7f73eff   bl           #0x1014737c
00147500 1016f500 0020       movs         r0, #0
00147502 1016f502 08bd       pop          {r3, pc}
00147504 1016f504 b479       ldrb         r4, [r6, #6]
00147506 1016f506 7810       asrs         r0, r7, #1
00147508 1016f508 2ccf       ldm          r7!, {r2, r3, r5}
0014750a 1016f50a 7d10       asrs         r5, r7, #1
0014750c 1016f50c 800f       lsrs         r0, r0, #0x1e
0014750e 1016f50e 2420       movs         r0, #0x24
00147510 1016f510 024b       ldr          r3, [pc, #8] ; literal raw=0x14751c: 0x20240f80
00147512 1016f512 0a46       mov          r2, r1
00147514 1016f514 0146       mov          r1, r0
00147516 1016f516 1868       ldr          r0, [r3]
00147518 1016f518 d3f734bf   b.w          #0x10143384
0014751c 1016f51c 800f       lsrs         r0, r0, #0x1e
0014751e 1016f51e 2420       movs         r0, #0x24
00147520 1016f520 2de9f047   push.w       {r4, r5, r6, r7, r8, sb, sl, lr}
00147524 1016f524 0623       movs         r3, #6
00147526 1016f526 86b0       sub          sp, #0x18
00147528 1016f528 4c4a       ldr          r2, [pc, #0x130] ; literal raw=0x14765c: 0x10787bf0 anc_load_cfg
0014752a 1016f52a 4220       movs         r0, #0x42
0014752c 1016f52c 4c49       ldr          r1, [pc, #0x130] ; literal raw=0x147660: 0x107879f0 [%s]:AUD_SECTION_STRUCT_VERSION=%d!
0014752e 1016f52e d0f7ebfe   bl           #0x10140308
00147532 1016f532 0320       movs         r0, #3
00147534 1016f534 0af0f6fa   bl           #0x10179b24
00147538 1016f538 4a49       ldr          r1, [pc, #0x128] ; literal raw=0x147664: 0x20240fac
0014753a 1016f53a 0a22       movs         r2, #0xa
0014753c 1016f53c 4a48       ldr          r0, [pc, #0x128] ; literal raw=0x147668: 0x201ed038
0014753e 1016f53e 44f13bfd   bl           #0x102b3fb8
00147542 1016f542 8046       mov          r8, r0
00147544 1016f544 4949       ldr          r1, [pc, #0x124] ; literal raw=0x14766c: 0x10787a14 50.7k!!!!
00147546 1016f546 4020       movs         r0, #0x40
00147548 1016f548 d0f7defe   bl           #0x10140308
0014754c 1016f54c b8f1000f   cmp.w        r8, #0
00147550 1016f550 09d0       beq          #0x1016f566
00147552 1016f552 4346       mov          r3, r8
00147554 1016f554 414a       ldr          r2, [pc, #0x104] ; literal raw=0x14765c: 0x10787bf0 anc_load_cfg
00147556 1016f556 4649       ldr          r1, [pc, #0x118] ; literal raw=0x147670: 0x10787a20 [%s] WARNING(%d): Can not load anc coefficient from audio section!!!
00147558 1016f558 4220       movs         r0, #0x42
0014755a 1016f55a d0f7d5fe   bl           #0x10140308
0014755e 1016f55e 4046       mov          r0, r8
00147560 1016f560 06b0       add          sp, #0x18
00147562 1016f562 bde8f087   pop.w        {r4, r5, r6, r7, r8, sb, sl, pc}
00147566 1016f566 3d4a       ldr          r2, [pc, #0xf4] ; literal raw=0x14765c: 0x10787bf0 anc_load_cfg
00147568 1016f568 4120       movs         r0, #0x41
0014756a 1016f56a 4249       ldr          r1, [pc, #0x108] ; literal raw=0x147674: 0x10787a68 [%s] Load anc coefficient from audio section.
0014756c 1016f56c 4546       mov          r5, r8
0014756e 1016f56e 3e4e       ldr          r6, [pc, #0xf8] ; literal raw=0x147668: 0x201ed038
00147570 1016f570 dff80891   ldr.w        sb, [pc, #0x108] ; literal raw=0x14767c: 0x10787a98 appmode%d,FEEDFORWARD,L:gain %d,R:gain %d
00147574 1016f574 d0f7c8fe   bl           #0x10140308
00147578 1016f578 56f8044b   ldr          r4, [r6], #4
0014757c 1016f57c 2a46       mov          r2, r5
0014757e 1016f57e 4946       mov          r1, sb
00147580 1016f580 4320       movs         r0, #0x43
00147582 1016f582 2368       ldr          r3, [r4]
00147584 1016f584 d4f85441   ldr.w        r4, [r4, #0x154]
00147588 1016f588 dff8f4a0   ldr.w        sl, [pc, #0xf4] ; literal raw=0x147680: 0x10787ac4 appmode%d,iir coef ff 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x
0014758c 1016f58c 0094       str          r4, [sp]
0014758e 1016f58e d0f7bbfe   bl           #0x10140308
00147592 1016f592 4ff0000c   mov.w        ip, #0
00147596 1016f596 0cf10104   add.w        r4, ip, #1
0014759a 1016f59a 56f8043c   ldr          r3, [r6, #-0x4]
0014759e 1016f59e 0ceb4c0c   add.w        ip, ip, ip, lsl #1
001475a2 1016f5a2 2a46       mov          r2, r5
001475a4 1016f5a4 04eb440e   add.w        lr, r4, r4, lsl #1
001475a8 1016f5a8 5146       mov          r1, sl
001475aa 1016f5aa 03ebcc0c   add.w        ip, r3, ip, lsl #3
001475ae 1016f5ae 4720       movs         r0, #0x47
001475b0 1016f5b0 03ebce0e   add.w        lr, r3, lr, lsl #3
001475b4 1016f5b4 dcf80830   ldr.w        r3, [ip, #8]
001475b8 1016f5b8 def804e0   ldr.w        lr, [lr, #4]
001475bc 1016f5bc cdf810e0   str.w        lr, [sp, #0x10]
001475c0 1016f5c0 dcf81870   ldr.w        r7, [ip, #0x18]
001475c4 1016f5c4 0397       str          r7, [sp, #0xc]
001475c6 1016f5c6 dcf81470   ldr.w        r7, [ip, #0x14]
001475ca 1016f5ca 0297       str          r7, [sp, #8]
001475cc 1016f5cc dcf81070   ldr.w        r7, [ip, #0x10]
001475d0 1016f5d0 0197       str          r7, [sp, #4]
001475d2 1016f5d2 dcf80c70   ldr.w        r7, [ip, #0xc]
001475d6 1016f5d6 0097       str          r7, [sp]
001475d8 1016f5d8 d0f796fe   bl           #0x10140308
001475dc 1016f5dc 0d2c       cmp          r4, #0xd
001475de 1016f5de a446       mov          ip, r4
001475e0 1016f5e0 d9d1       bne          #0x1016f596
001475e2 1016f5e2 56f8044c   ldr          r4, [r6, #-0x4]
001475e6 1016f5e6 2a46       mov          r2, r5
001475e8 1016f5e8 2349       ldr          r1, [pc, #0x8c] ; literal raw=0x147678: 0x10787b0c appmode%d,FEEDBACK,L:gain %d,R:gain %d
001475ea 1016f5ea 4320       movs         r0, #0x43
001475ec 1016f5ec d4f8a03a   ldr.w        r3, [r4, #0xaa0]
001475f0 1016f5f0 d4f8f44b   ldr.w        r4, [r4, #0xbf4]
001475f4 1016f5f4 dff88ca0   ldr.w        sl, [pc, #0x8c] ; literal raw=0x147684: 0x10787b34 appmode%d,iir coef fb 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x, 0x%08x
001475f8 1016f5f8 0094       str          r4, [sp]
001475fa 1016f5fa d0f785fe   bl           #0x10140308
001475fe 1016f5fe 4ff0000c   mov.w        ip, #0
00147602 1016f602 0cf10107   add.w        r7, ip, #1
00147606 1016f606 56f8043c   ldr          r3, [r6, #-0x4]
0014760a 1016f60a 0ceb4c0c   add.w        ip, ip, ip, lsl #1
0014760e 1016f60e 2a46       mov          r2, r5
00147610 1016f610 07eb4704   add.w        r4, r7, r7, lsl #1
00147614 1016f614 5146       mov          r1, sl
00147616 1016f616 03ebcc0c   add.w        ip, r3, ip, lsl #3
0014761a 1016f61a 4720       movs         r0, #0x47
0014761c 1016f61c 03ebc404   add.w        r4, r3, r4, lsl #3
00147620 1016f620 dcf8a83a   ldr.w        r3, [ip, #0xaa8]
00147624 1016f624 d4f8a44a   ldr.w        r4, [r4, #0xaa4]
00147628 1016f628 0494       str          r4, [sp, #0x10]
0014762a 1016f62a dcf8b84a   ldr.w        r4, [ip, #0xab8]
0014762e 1016f62e 0394       str          r4, [sp, #0xc]
00147630 1016f630 dcf8b44a   ldr.w        r4, [ip, #0xab4]
00147634 1016f634 0294       str          r4, [sp, #8]
00147636 1016f636 dcf8b04a   ldr.w        r4, [ip, #0xab0]
0014763a 1016f63a 0194       str          r4, [sp, #4]
0014763c 1016f63c dcf8ac4a   ldr.w        r4, [ip, #0xaac]
00147640 1016f640 0094       str          r4, [sp]
00147642 1016f642 d0f761fe   bl           #0x10140308
00147646 1016f646 0d2f       cmp          r7, #0xd
00147648 1016f648 bc46       mov          ip, r7
0014764a 1016f64a dad1       bne          #0x1016f602
0014764c 1016f64c 0135       adds         r5, #1
0014764e 1016f64e 0a2d       cmp          r5, #0xa
00147650 1016f650 92d1       bne          #0x1016f578
00147652 1016f652 4046       mov          r0, r8
00147654 1016f654 06b0       add          sp, #0x18
00147656 1016f656 bde8f087   pop.w        {r4, r5, r6, r7, r8, sb, sl, pc}
0014765a 1016f65a 00bf       nop          
0014765c 1016f65c f07b       ldrb         r0, [r6, #0xf]
0014765e 1016f65e 7810       asrs         r0, r7, #1
00147660 1016f660 f079       ldrb         r0, [r6, #7]
00147662 1016f662 7810       asrs         r0, r7, #1
00147664 1016f664 ac0f       lsrs         r4, r5, #0x1e
00147666 1016f666 2420       movs         r0, #0x24
00147668 1016f668 38d0       beq          #0x1016f6dc
0014766a 1016f66a 1e20       movs         r0, #0x1e
0014766c 1016f66c 147a       ldrb         r4, [r2, #8]
0014766e 1016f66e 7810       asrs         r0, r7, #1
00147670 1016f670 207a       ldrb         r0, [r4, #8]
00147672 1016f672 7810       asrs         r0, r7, #1
00147674 1016f674 687a       ldrb         r0, [r5, #9]
00147676 1016f676 7810       asrs         r0, r7, #1
00147678 1016f678 0c7b       ldrb         r4, [r1, #0xc]
0014767a 1016f67a 7810       asrs         r0, r7, #1
0014767c 1016f67c 987a       ldrb         r0, [r3, #0xa]
0014767e 1016f67e 7810       asrs         r0, r7, #1
00147680 1016f680 c47a       ldrb         r4, [r0, #0xb]
00147682 1016f682 7810       asrs         r0, r7, #1
00147684 1016f684 347b       ldrb         r4, [r6, #0xc]
00147686 1016f686 7810       asrs         r0, r7, #1
00147688 1016f688 0929       cmp          r1, #9
0014768a 1016f68a 2de9f041   push.w       {r4, r5, r6, r7, r8, lr}
0014768e 1016f68e 0c46       mov          r4, r1
00147690 1016f690 82b0       sub          sp, #8
00147692 1016f692 1646       mov          r6, r2
00147694 1016f694 3ad8       bhi          #0x1016f70c
00147696 1016f696 9846       mov          r8, r3
00147698 1016f698 4bf68033   movw         r3, #0xbb80
0014769c 1016f69c 0546       mov          r5, r0
0014769e 1016f69e 9842       cmp          r0, r3
001476a0 1016f6a0 20d0       beq          #0x1016f6e4
001476a2 1016f6a2 4cf25d63   movw         r3, #0xc65d
001476a6 1016f6a6 9842       cmp          r0, r3
001476a8 1016f6a8 1ad0       beq          #0x1016f6e0
001476aa 1016f6aa 4af64443   movw         r3, #0xac44
001476ae 1016f6ae 9842       cmp          r0, r3
001476b0 1016f6b0 03d0       beq          #0x1016f6ba
001476b2 1016f6b2 2946       mov          r1, r5
001476b4 1016f6b4 1b48       ldr          r0, [pc, #0x6c] ; literal raw=0x147724: 0x10787bbc The coefs of Samprate %d is NULL
001476b6 1016f6b6 d1f7d3f8   bl           #0x10140860
001476ba 1016f6ba 1b4f       ldr          r7, [pc, #0x6c] ; literal raw=0x147728: 0x20240f84
001476bc 1016f6bc 57f82430   ldr.w        r3, [r7, r4, lsl #2]
001476c0 1016f6c0 07eb8407   add.w        r7, r7, r4, lsl #2
001476c4 1016f6c4 002b       cmp          r3, #0
001476c6 1016f6c6 f4d0       beq          #0x1016f6b2
001476c8 1016f6c8 3046       mov          r0, r6
001476ca 1016f6ca 06f057fe   bl           #0x1017637c
001476ce 1016f6ce 58b9       cbnz         r0, #0x1016f6e8
001476d0 1016f6d0 164a       ldr          r2, [pc, #0x58] ; literal raw=0x14772c: 0x20240fd4
001476d2 1016f6d2 0020       movs         r0, #0
001476d4 1016f6d4 164b       ldr          r3, [pc, #0x58] ; literal raw=0x147730: 0x20240fd8
001476d6 1016f6d6 1470       strb         r4, [r2]
001476d8 1016f6d8 1d60       str          r5, [r3]
001476da 1016f6da 02b0       add          sp, #8
001476dc 1016f6dc bde8f081   pop.w        {r4, r5, r6, r7, r8, pc}
001476e0 1016f6e0 144f       ldr          r7, [pc, #0x50] ; literal raw=0x147734: 0x201ed038
001476e2 1016f6e2 ebe7       b            #0x1016f6bc
001476e4 1016f6e4 144f       ldr          r7, [pc, #0x50] ; literal raw=0x147738: 0x20240fac
001476e6 1016f6e6 e9e7       b            #0x1016f6bc
001476e8 1016f6e8 3868       ldr          r0, [r7]
001476ea 1016f6ea 5cf727fc   bl           #0x100cbf3c
001476ee 1016f6ee 0746       mov          r7, r0
001476f0 1016f6f0 0f21       movs         r1, #0xf
001476f2 1016f6f2 0520       movs         r0, #5
001476f4 1016f6f4 d2f7a8f8   bl           #0x10141848
001476f8 1016f6f8 3146       mov          r1, r6
001476fa 1016f6fa 4246       mov          r2, r8
001476fc 1016f6fc 3846       mov          r0, r7
001476fe 1016f6fe 05f017ff   bl           #0x10175530
00147702 1016f702 0021       movs         r1, #0
00147704 1016f704 0520       movs         r0, #5
00147706 1016f706 d2f79ff8   bl           #0x10141848
0014770a 1016f70a e1e7       b            #0x1016f6d0
0014770c 1016f70c 1346       mov          r3, r2
0014770e 1016f70e 0b49       ldr          r1, [pc, #0x2c] ; literal raw=0x14773c: 0x10787b7c [%s] WARNING: anc_type: 0x%x, index(%d) >= ANC_COEF_LIST_NUM
00147710 1016f710 0b4a       ldr          r2, [pc, #0x2c] ; literal raw=0x147740: 0x10787be0 anc_select_coef
00147712 1016f712 4320       movs         r0, #0x43
00147714 1016f714 0094       str          r4, [sp]
00147716 1016f716 d0f7f7fd   bl           #0x10140308
0014771a 1016f71a 0120       movs         r0, #1
0014771c 1016f71c 02b0       add          sp, #8
0014771e 1016f71e bde8f081   pop.w        {r4, r5, r6, r7, r8, pc}
00147722 1016f722 00bf       nop          
00147724 1016f724 bc7b       ldrb         r4, [r7, #0xe]
00147726 1016f726 7810       asrs         r0, r7, #1
00147728 1016f728 840f       lsrs         r4, r0, #0x1e
0014772a 1016f72a 2420       movs         r0, #0x24
0014772c 1016f72c d40f       lsrs         r4, r2, #0x1f
0014772e 1016f72e 2420       movs         r0, #0x24
00147730 1016f730 d80f       lsrs         r0, r3, #0x1f
00147732 1016f732 2420       movs         r0, #0x24
00147734 1016f734 38d0       beq          #0x1016f7a8
00147736 1016f736 1e20       movs         r0, #0x1e
00147738 1016f738 ac0f       lsrs         r4, r5, #0x1e
0014773a 1016f73a 2420       movs         r0, #0x24
0014773c 1016f73c 7c7b       ldrb         r4, [r7, #0xd]
0014773e 1016f73e 7810       asrs         r0, r7, #1
00147740 1016f740 e07b       ldrb         r0, [r4, #0xf]
00147742 1016f742 7810       asrs         r0, r7, #1
00147744 1016f744 4bf68032   movw         r2, #0xbb80
00147748 1016f748 0346       mov          r3, r0
0014774a 1016f74a 9042       cmp          r0, r2
0014774c 1016f74c 0cd0       beq          #0x1016f768
0014774e 1016f74e 4cf25d62   movw         r2, #0xc65d
00147752 1016f752 9042       cmp          r0, r2
00147754 1016f754 06d0       beq          #0x1016f764
00147756 1016f756 4af64442   movw         r2, #0xac44
0014775a 1016f75a 0448       ldr          r0, [pc, #0x10] ; literal raw=0x14776c: 0x20240f84
0014775c 1016f75c 9342       cmp          r3, r2
0014775e 1016f75e 18bf       it           ne
00147760 1016f760 0020       movne        r0, #0
00147762 1016f762 7047       bx           lr
00147764 1016f764 0248       ldr          r0, [pc, #8] ; literal raw=0x147770: 0x201ed038
00147766 1016f766 7047       bx           lr
00147768 1016f768 0248       ldr          r0, [pc, #8] ; literal raw=0x147774: 0x20240fac
0014776a 1016f76a 7047       bx           lr
0014776c 1016f76c 840f       lsrs         r4, r0, #0x1e
0014776e 1016f76e 2420       movs         r0, #0x24
00147770 1016f770 38d0       beq          #0x1016f7e4
00147772 1016f772 1e20       movs         r0, #0x1e
00147774 1016f774 ac0f       lsrs         r4, r5, #0x1e
00147776 1016f776 2420       movs         r0, #0x24
00147778 1016f778 b0ee407a   vmov.f32     s14, s0
0014777c 1016f77c f3ee047a   vmov.f32     s15, #2.000000e+01
00147780 1016f780 b2ee040a   vmov.f32     s0, #1.000000e+01
00147784 1016f784 10b5       push         {r4, lr}
00147786 1016f786 2ded0a8b   vpush        {d8, d9, d10, d11, d12}
0014778a 1016f78a f0ee609a   vmov.f32     s19, s1
0014778e 1016f78e 0446       mov          r4, r0
00147790 1016f790 c7ee270a   vdiv.f32     s1, s14, s15
00147794 1016f794 b0ee418a   vmov.f32     s16, s2
00147798 1016f798 52f1d6fb   bl           #0x102c1f48
0014779c 1016f79c b5ee400a   vcmp.f32     s0, #0
001477a0 1016f7a0 f1ee10fa   vmrs         apsr_nzcv, fpscr
001477a4 1016f7a4 62d4       bmi          #0x1016f86c
001477a6 1016f7a6 f1eec08a   vsqrt.f32    s17, s0
001477aa 1016f7aa dfed4f7a   vldr         s15, [pc, #0x13c] ; literal raw=0x1478e8: 0x40c90fdb
001477ae 1016f7ae 69eea79a   vmul.f32     s19, s19, s15
001477b2 1016f7b2 b7ee009a   vmov.f32     s18, #1.000000e+00
001477b6 1016f7b6 38ee088a   vadd.f32     s16, s16, s16
001477ba 1016f7ba b0ee690a   vmov.f32     s0, s19
001477be 1016f7be 52f157fd   bl           #0x102c2270
001477c2 1016f7c2 f0ee407a   vmov.f32     s15, s0
001477c6 1016f7c6 b0ee690a   vmov.f32     s0, s19
001477ca 1016f7ca 78ee89ba   vadd.f32     s23, s17, s18
001477ce 1016f7ce 87ee88ba   vdiv.f32     s22, s15, s16
001477d2 1016f7d2 50f1edff   bl           #0x102c07b0
001477d6 1016f7d6 38eec99a   vsub.f32     s18, s17, s18
001477da 1016f7da f5ee408a   vcmp.f32     s17, #0
001477de 1016f7de b0ee40aa   vmov.f32     s20, s0
001477e2 1016f7e2 29ee008a   vmul.f32     s16, s18, s0
001477e6 1016f7e6 f1ee10fa   vmrs         apsr_nzcv, fpscr
001477ea 1016f7ea 7bee88aa   vadd.f32     s21, s23, s16
001477ee 1016f7ee 42d4       bmi          #0x1016f876
001477f0 1016f7f0 f1eee87a   vsqrt.f32    s15, s17
001477f4 1016f7f4 3beec88a   vsub.f32     s16, s23, s16
001477f8 1016f7f8 b0ee49ca   vmov.f32     s24, s18
001477fc 1016f7fc f0ee6a9a   vmov.f32     s19, s21
00147800 1016f800 b0ee48aa   vmov.f32     s20, s16
00147804 1016f804 abee80ca   vfma.f32     s24, s23, s0
00147808 1016f808 abeec09a   vfms.f32     s18, s23, s0
0014780c 1016f80c f8ee006a   vmov.f32     s13, #-2.000000e+00
00147810 1016f810 38eea87a   vadd.f32     s14, s17, s17
00147814 1016f814 2cee26ca   vmul.f32     s24, s24, s13
00147818 1016f818 77eea77a   vadd.f32     s15, s15, s15
0014781c 1016f81c 27ee099a   vmul.f32     s18, s14, s18
00147820 1016f820 abee27aa   vfma.f32     s20, s22, s15
00147824 1016f824 ebee279a   vfma.f32     s19, s22, s15
00147828 1016f828 ebee67aa   vfms.f32     s21, s22, s15
0014782c 1016f82c 28ee8aaa   vmul.f32     s20, s17, s20
00147830 1016f830 a7eecb8a   vfms.f32     s16, s15, s22
00147834 1016f834 4ff07e53   mov.w        r3, #0x3f800000
00147838 1016f838 ccee295a   vdiv.f32     s11, s24, s19
0014783c 1016f83c 2360       str          r3, [r4]
0014783e 1016f83e 28ee288a   vmul.f32     s16, s16, s17
00147842 1016f842 8aeea96a   vdiv.f32     s12, s21, s19
00147846 1016f846 caee296a   vdiv.f32     s13, s20, s19
0014784a 1016f84a 89ee297a   vdiv.f32     s14, s18, s19
0014784e 1016f84e c4ed015a   vstr         s11, [r4, #4]
00147852 1016f852 c8ee297a   vdiv.f32     s15, s16, s19
00147856 1016f856 84ed026a   vstr         s12, [r4, #8]
0014785a 1016f85a c4ed036a   vstr         s13, [r4, #0xc]
0014785e 1016f85e 84ed047a   vstr         s14, [r4, #0x10]
00147862 1016f862 c4ed057a   vstr         s15, [r4, #0x14]
00147866 1016f866 bdec0a8b   vpop         {d8, d9, d10, d11, d12}
0014786a 1016f86a 10bd       pop          {r4, pc}
0014786c 1016f86c 52f1dafe   bl           #0x102c2624
00147870 1016f870 f0ee408a   vmov.f32     s17, s0
00147874 1016f874 99e7       b            #0x1016f7aa
00147876 1016f876 b0ee49ca   vmov.f32     s24, s18
0014787a 1016f87a b0ee680a   vmov.f32     s0, s17
0014787e 1016f87e 52f1d1fe   bl           #0x102c2624
00147882 1016f882 f0ee6a9a   vmov.f32     s19, s21
00147886 1016f886 abee8aca   vfma.f32     s24, s23, s20
0014788a 1016f88a b8ee007a   vmov.f32     s14, #-2.000000e+00
0014788e 1016f88e 70ee007a   vadd.f32     s15, s0, s0
00147892 1016f892 b0ee680a   vmov.f32     s0, s17
00147896 1016f896 ebee279a   vfma.f32     s19, s22, s15
0014789a 1016f89a 2cee07ca   vmul.f32     s24, s24, s14
0014789e 1016f89e 52f1c1fe   bl           #0x102c2624
001478a2 1016f8a2 f0ee407a   vmov.f32     s15, s0
001478a6 1016f8a6 b0ee680a   vmov.f32     s0, s17
001478aa 1016f8aa 3beec88a   vsub.f32     s16, s23, s16
001478ae 1016f8ae 77eea77a   vadd.f32     s15, s15, s15
001478b2 1016f8b2 ebee67aa   vfms.f32     s21, s22, s15
001478b6 1016f8b6 52f1b5fe   bl           #0x102c2624
001478ba 1016f8ba b0ee407a   vmov.f32     s14, s0
001478be 1016f8be abeeca9a   vfms.f32     s18, s23, s20
001478c2 1016f8c2 b0ee48aa   vmov.f32     s20, s16
001478c6 1016f8c6 37ee077a   vadd.f32     s14, s14, s14
001478ca 1016f8ca 78eea87a   vadd.f32     s15, s17, s17
001478ce 1016f8ce b0ee680a   vmov.f32     s0, s17
001478d2 1016f8d2 abee07aa   vfma.f32     s20, s22, s14
001478d6 1016f8d6 27ee899a   vmul.f32     s18, s15, s18
001478da 1016f8da 52f1a3fe   bl           #0x102c2624
001478de 1016f8de 70ee007a   vadd.f32     s15, s0, s0
001478e2 1016f8e2 28ee8aaa   vmul.f32     s20, s17, s20
001478e6 1016f8e6 a3e7       b            #0x1016f830
001478e8 1016f8e8 db0f       lsrs         r3, r3, #0x1f
001478ea 1016f8ea c940       lsrs         r1, r1
001478ec 1016f8ec b0ee407a   vmov.f32     s14, s0
001478f0 1016f8f0 f3ee047a   vmov.f32     s15, #2.000000e+01
001478f4 1016f8f4 b2ee040a   vmov.f32     s0, #1.000000e+01
001478f8 1016f8f8 10b5       push         {r4, lr}
001478fa 1016f8fa 2ded088b   vpush        {d8, d9, d10, d11}
001478fe 1016f8fe f0ee609a   vmov.f32     s19, s1
00147902 1016f902 82b0       sub          sp, #8
00147904 1016f904 c7ee270a   vdiv.f32     s1, s14, s15
00147908 1016f908 0446       mov          r4, r0
0014790a 1016f90a b0ee418a   vmov.f32     s16, s2
0014790e 1016f90e 52f11bfb   bl           #0x102c1f48
00147912 1016f912 b5ee400a   vcmp.f32     s0, #0
00147916 1016f916 f1ee10fa   vmrs         apsr_nzcv, fpscr
0014791a 1016f91a 63d4       bmi          #0x1016f9e4
0014791c 1016f91c b1eec09a   vsqrt.f32    s18, s0
00147920 1016f920 dfed527a   vldr         s15, [pc, #0x148] ; literal raw=0x147a6c: 0x40c90fdb
00147924 1016f924 69eea79a   vmul.f32     s19, s19, s15
00147928 1016f928 f7ee008a   vmov.f32     s17, #1.000000e+00
0014792c 1016f92c 38ee088a   vadd.f32     s16, s16, s16
00147930 1016f930 b0ee690a   vmov.f32     s0, s19
00147934 1016f934 52f19cfc   bl           #0x102c2270
00147938 1016f938 f0ee407a   vmov.f32     s15, s0
0014793c 1016f93c b0ee690a   vmov.f32     s0, s19
00147940 1016f940 79ee28ba   vadd.f32     s23, s18, s17
00147944 1016f944 87ee88ba   vdiv.f32     s22, s15, s16
00147948 1016f948 50f132ff   bl           #0x102c07b0
0014794c 1016f94c 79ee688a   vsub.f32     s17, s18, s17
00147950 1016f950 b5ee409a   vcmp.f32     s18, #0
00147954 1016f954 b0ee40aa   vmov.f32     s20, s0
00147958 1016f958 28ee808a   vmul.f32     s16, s17, s0
0014795c 1016f95c f1ee10fa   vmrs         apsr_nzcv, fpscr
00147960 1016f960 7beec8aa   vsub.f32     s21, s23, s16
00147964 1016f964 43d4       bmi          #0x1016f9ee
00147966 1016f966 f1eec97a   vsqrt.f32    s15, s18
0014796a 1016f96a 3bee888a   vadd.f32     s16, s23, s16
0014796e 1016f96e f0ee686a   vmov.f32     s13, s17
00147972 1016f972 f0ee6a9a   vmov.f32     s19, s21
00147976 1016f976 b0ee48aa   vmov.f32     s20, s16
0014797a 1016f97a ebeec06a   vfms.f32     s13, s23, s0
0014797e 1016f97e ebee808a   vfma.f32     s17, s23, s0
00147982 1016f982 b8ee007a   vmov.f32     s14, #-2.000000e+00
00147986 1016f986 29ee077a   vmul.f32     s14, s18, s14
0014798a 1016f98a 76eea66a   vadd.f32     s13, s13, s13
0014798e 1016f98e 77eea77a   vadd.f32     s15, s15, s15
00147992 1016f992 67ee288a   vmul.f32     s17, s14, s17
00147996 1016f996 abee27aa   vfma.f32     s20, s22, s15
0014799a 1016f99a ebee279a   vfma.f32     s19, s22, s15
0014799e 1016f99e ebee67aa   vfms.f32     s21, s22, s15
001479a2 1016f9a2 29ee0aaa   vmul.f32     s20, s18, s20
001479a6 1016f9a6 a7eecb8a   vfms.f32     s16, s15, s22
001479aa 1016f9aa 4ff07e53   mov.w        r3, #0x3f800000
001479ae 1016f9ae c6eea95a   vdiv.f32     s11, s13, s19
001479b2 1016f9b2 2360       str          r3, [r4]
001479b4 1016f9b4 28ee098a   vmul.f32     s16, s16, s18
001479b8 1016f9b8 8aeea96a   vdiv.f32     s12, s21, s19
001479bc 1016f9bc caee296a   vdiv.f32     s13, s20, s19
001479c0 1016f9c0 88eea97a   vdiv.f32     s14, s17, s19
001479c4 1016f9c4 c4ed015a   vstr         s11, [r4, #4]
001479c8 1016f9c8 c8ee297a   vdiv.f32     s15, s16, s19
001479cc 1016f9cc 84ed026a   vstr         s12, [r4, #8]
001479d0 1016f9d0 c4ed036a   vstr         s13, [r4, #0xc]
001479d4 1016f9d4 84ed047a   vstr         s14, [r4, #0x10]
001479d8 1016f9d8 c4ed057a   vstr         s15, [r4, #0x14]
001479dc 1016f9dc 02b0       add          sp, #8
001479de 1016f9de bdec088b   vpop         {d8, d9, d10, d11}
001479e2 1016f9e2 10bd       pop          {r4, pc}
001479e4 1016f9e4 52f11efe   bl           #0x102c2624
001479e8 1016f9e8 b0ee409a   vmov.f32     s18, s0
001479ec 1016f9ec 98e7       b            #0x1016f920
001479ee 1016f9ee b0ee490a   vmov.f32     s0, s18
001479f2 1016f9f2 52f117fe   bl           #0x102c2624
001479f6 1016f9f6 f0ee686a   vmov.f32     s13, s17
001479fa 1016f9fa f0ee407a   vmov.f32     s15, s0
001479fe 1016f9fe f0ee6a9a   vmov.f32     s19, s21
00147a02 1016fa02 ebeeca6a   vfms.f32     s13, s23, s20
00147a06 1016fa06 77eea77a   vadd.f32     s15, s15, s15
00147a0a 1016fa0a b0ee490a   vmov.f32     s0, s18
00147a0e 1016fa0e ebee279a   vfma.f32     s19, s22, s15
00147a12 1016fa12 76eea66a   vadd.f32     s13, s13, s13
00147a16 1016fa16 cded016a   vstr         s13, [sp, #4]
00147a1a 1016fa1a 52f103fe   bl           #0x102c2624
00147a1e 1016fa1e f0ee407a   vmov.f32     s15, s0
00147a22 1016fa22 b0ee490a   vmov.f32     s0, s18
00147a26 1016fa26 3bee888a   vadd.f32     s16, s23, s16
00147a2a 1016fa2a 77eea77a   vadd.f32     s15, s15, s15
00147a2e 1016fa2e ebee67aa   vfms.f32     s21, s22, s15
00147a32 1016fa32 52f1f7fd   bl           #0x102c2624
00147a36 1016fa36 b0ee407a   vmov.f32     s14, s0
00147a3a 1016fa3a ebee8a8a   vfma.f32     s17, s23, s20
00147a3e 1016fa3e b0ee48aa   vmov.f32     s20, s16
00147a42 1016fa42 37ee077a   vadd.f32     s14, s14, s14
00147a46 1016fa46 f8ee007a   vmov.f32     s15, #-2.000000e+00
00147a4a 1016fa4a b0ee490a   vmov.f32     s0, s18
00147a4e 1016fa4e abee07aa   vfma.f32     s20, s22, s14
00147a52 1016fa52 69ee277a   vmul.f32     s15, s18, s15
00147a56 1016fa56 67eea88a   vmul.f32     s17, s15, s17
00147a5a 1016fa5a 52f1e3fd   bl           #0x102c2624
00147a5e 1016fa5e dded016a   vldr         s13, [sp, #4]
00147a62 1016fa62 70ee007a   vadd.f32     s15, s0, s0
00147a66 1016fa66 29ee0aaa   vmul.f32     s20, s18, s20
00147a6a 1016fa6a 9ce7       b            #0x1016f9a6
00147a6c 1016fa6c db0f       lsrs         r3, r3, #0x1f
00147a6e 1016fa6e c940       lsrs         r1, r1
00147a70 1016fa70 b0ee407a   vmov.f32     s14, s0
00147a74 1016fa74 f3ee047a   vmov.f32     s15, #2.000000e+01
00147a78 1016fa78 b2ee040a   vmov.f32     s0, #1.000000e+01
00147a7c 1016fa7c 10b5       push         {r4, lr}
00147a7e 1016fa7e 2ded048b   vpush        {d8, d9}
00147a82 1016fa82 b0ee609a   vmov.f32     s18, s1
00147a86 1016fa86 0446       mov          r4, r0
00147a88 1016fa88 c7ee270a   vdiv.f32     s1, s14, s15
00147a8c 1016fa8c f0ee418a   vmov.f32     s17, s2
00147a90 1016fa90 52f15afa   bl           #0x102c1f48
00147a94 1016fa94 b5ee400a   vcmp.f32     s0, #0
00147a98 1016fa98 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147a9c 1016fa9c 3ed4       bmi          #0x1016fb1c
00147a9e 1016fa9e f1eec09a   vsqrt.f32    s19, s0
00147aa2 1016faa2 dfed217a   vldr         s15, [pc, #0x84] ; literal raw=0x147b28: 0x40c90fdb
00147aa6 1016faa6 29ee279a   vmul.f32     s18, s18, s15
00147aaa 1016faaa 78eea88a   vadd.f32     s17, s17, s17
00147aae 1016faae b7ee008a   vmov.f32     s16, #1.000000e+00
00147ab2 1016fab2 b0ee490a   vmov.f32     s0, s18
00147ab6 1016fab6 52f1dbfb   bl           #0x102c2270
00147aba 1016faba f0ee407a   vmov.f32     s15, s0
00147abe 1016fabe b0ee490a   vmov.f32     s0, s18
00147ac2 1016fac2 87eea89a   vdiv.f32     s18, s15, s17
00147ac6 1016fac6 50f173fe   bl           #0x102c07b0
00147aca 1016faca 84ed008a   vstr         s16, [r4]
00147ace 1016face f0ee486a   vmov.f32     s13, s16
00147ad2 1016fad2 b0ee485a   vmov.f32     s10, s16
00147ad6 1016fad6 f8ee007a   vmov.f32     s15, #-2.000000e+00
00147ada 1016fada 20ee270a   vmul.f32     s0, s0, s15
00147ade 1016fade 89ee297a   vdiv.f32     s14, s18, s19
00147ae2 1016fae2 e9ee296a   vfma.f32     s13, s18, s19
00147ae6 1016fae6 a9ee695a   vfms.f32     s10, s18, s19
00147aea 1016faea 77ee087a   vadd.f32     s15, s14, s16
00147aee 1016faee 38ee478a   vsub.f32     s16, s16, s14
00147af2 1016faf2 86eea76a   vdiv.f32     s12, s13, s15
00147af6 1016faf6 80ee277a   vdiv.f32     s14, s0, s15
00147afa 1016fafa c8ee275a   vdiv.f32     s11, s16, s15
00147afe 1016fafe c5ee276a   vdiv.f32     s13, s10, s15
00147b02 1016fb02 84ed036a   vstr         s12, [r4, #0xc]
00147b06 1016fb06 84ed017a   vstr         s14, [r4, #4]
00147b0a 1016fb0a 84ed047a   vstr         s14, [r4, #0x10]
00147b0e 1016fb0e c4ed025a   vstr         s11, [r4, #8]
00147b12 1016fb12 c4ed056a   vstr         s13, [r4, #0x14]
00147b16 1016fb16 bdec048b   vpop         {d8, d9}
00147b1a 1016fb1a 10bd       pop          {r4, pc}
00147b1c 1016fb1c 52f182fd   bl           #0x102c2624
00147b20 1016fb20 f0ee409a   vmov.f32     s19, s0
00147b24 1016fb24 bde7       b            #0x1016faa2
00147b26 1016fb26 00bf       nop          
00147b28 1016fb28 db0f       lsrs         r3, r3, #0x1f
00147b2a 1016fb2a c940       lsrs         r1, r1
00147b2c 1016fb2c 10b5       push         {r4, lr}
00147b2e 1016fb2e 2ded048b   vpush        {d8, d9}
00147b32 1016fb32 9fed1f9a   vldr         s18, [pc, #0x7c] ; literal raw=0x147bb0: 0x40c90fdb
00147b36 1016fb36 f0ee418a   vmov.f32     s17, s2
00147b3a 1016fb3a 0446       mov          r4, r0
00147b3c 1016fb3c b7ee008a   vmov.f32     s16, #1.000000e+00
00147b40 1016fb40 20ee899a   vmul.f32     s18, s1, s18
00147b44 1016fb44 78eea88a   vadd.f32     s17, s17, s17
00147b48 1016fb48 b0ee490a   vmov.f32     s0, s18
00147b4c 1016fb4c 52f190fb   bl           #0x102c2270
00147b50 1016fb50 f0ee407a   vmov.f32     s15, s0
00147b54 1016fb54 b0ee490a   vmov.f32     s0, s18
00147b58 1016fb58 87eea89a   vdiv.f32     s18, s15, s17
00147b5c 1016fb5c 50f128fe   bl           #0x102c07b0
00147b60 1016fb60 84ed008a   vstr         s16, [r4]
00147b64 1016fb64 70ee087a   vadd.f32     s15, s0, s16
00147b68 1016fb68 f8ee006a   vmov.f32     s13, #-2.000000e+00
00147b6c 1016fb6c b6ee007a   vmov.f32     s14, #5.000000e-01
00147b70 1016fb70 20ee260a   vmul.f32     s0, s0, s13
00147b74 1016fb74 67ee876a   vmul.f32     s13, s15, s14
00147b78 1016fb78 b1ee677a   vneg.f32     s14, s15
00147b7c 1016fb7c 79ee087a   vadd.f32     s15, s18, s16
00147b80 1016fb80 38ee498a   vsub.f32     s16, s16, s18
00147b84 1016fb84 86eea76a   vdiv.f32     s12, s13, s15
00147b88 1016fb88 c8ee275a   vdiv.f32     s11, s16, s15
00147b8c 1016fb8c 80ee275a   vdiv.f32     s10, s0, s15
00147b90 1016fb90 c7ee276a   vdiv.f32     s13, s14, s15
00147b94 1016fb94 84ed036a   vstr         s12, [r4, #0xc]
00147b98 1016fb98 84ed056a   vstr         s12, [r4, #0x14]
00147b9c 1016fb9c c4ed025a   vstr         s11, [r4, #8]
00147ba0 1016fba0 84ed015a   vstr         s10, [r4, #4]
00147ba4 1016fba4 c4ed046a   vstr         s13, [r4, #0x10]
00147ba8 1016fba8 bdec048b   vpop         {d8, d9}
00147bac 1016fbac 10bd       pop          {r4, pc}
00147bae 1016fbae 00bf       nop          
00147bb0 1016fbb0 db0f       lsrs         r3, r3, #0x1f
00147bb2 1016fbb2 c940       lsrs         r1, r1
00147bb4 1016fbb4 10b5       push         {r4, lr}
00147bb6 1016fbb6 2ded048b   vpush        {d8, d9}
00147bba 1016fbba 9fed1e9a   vldr         s18, [pc, #0x78] ; literal raw=0x147c34: 0x40c90fdb
00147bbe 1016fbbe f0ee418a   vmov.f32     s17, s2
00147bc2 1016fbc2 0446       mov          r4, r0
00147bc4 1016fbc4 b7ee008a   vmov.f32     s16, #1.000000e+00
00147bc8 1016fbc8 20ee899a   vmul.f32     s18, s1, s18
00147bcc 1016fbcc 78eea88a   vadd.f32     s17, s17, s17
00147bd0 1016fbd0 b0ee490a   vmov.f32     s0, s18
00147bd4 1016fbd4 52f14cfb   bl           #0x102c2270
00147bd8 1016fbd8 f0ee407a   vmov.f32     s15, s0
00147bdc 1016fbdc b0ee490a   vmov.f32     s0, s18
00147be0 1016fbe0 87eea89a   vdiv.f32     s18, s15, s17
00147be4 1016fbe4 50f1e4fd   bl           #0x102c07b0
00147be8 1016fbe8 84ed008a   vstr         s16, [r4]
00147bec 1016fbec 38ee406a   vsub.f32     s12, s16, s0
00147bf0 1016fbf0 b8ee007a   vmov.f32     s14, #-2.000000e+00
00147bf4 1016fbf4 f6ee007a   vmov.f32     s15, #5.000000e-01
00147bf8 1016fbf8 20ee070a   vmul.f32     s0, s0, s14
00147bfc 1016fbfc 26ee277a   vmul.f32     s14, s12, s15
00147c00 1016fc00 79ee087a   vadd.f32     s15, s18, s16
00147c04 1016fc04 38ee498a   vsub.f32     s16, s16, s18
00147c08 1016fc08 c7ee276a   vdiv.f32     s13, s14, s15
00147c0c 1016fc0c c8ee275a   vdiv.f32     s11, s16, s15
00147c10 1016fc10 80ee275a   vdiv.f32     s10, s0, s15
00147c14 1016fc14 86ee277a   vdiv.f32     s14, s12, s15
00147c18 1016fc18 c4ed036a   vstr         s13, [r4, #0xc]
00147c1c 1016fc1c c4ed056a   vstr         s13, [r4, #0x14]
00147c20 1016fc20 c4ed025a   vstr         s11, [r4, #8]
00147c24 1016fc24 84ed015a   vstr         s10, [r4, #4]
00147c28 1016fc28 84ed047a   vstr         s14, [r4, #0x10]
00147c2c 1016fc2c bdec048b   vpop         {d8, d9}
00147c30 1016fc30 10bd       pop          {r4, pc}
00147c32 1016fc32 00bf       nop          
00147c34 1016fc34 db0f       lsrs         r3, r3, #0x1f
00147c36 1016fc36 c940       lsrs         r1, r1
00147c38 1016fc38 f0ee400a   vmov.f32     s1, s0
00147c3c 1016fc3c f3ee047a   vmov.f32     s15, #2.000000e+01
00147c40 1016fc40 b2ee040a   vmov.f32     s0, #1.000000e+01
00147c44 1016fc44 c0eea70a   vdiv.f32     s1, s1, s15
00147c48 1016fc48 52f17eb9   b.w          #0x102c1f48
00147c4c 1016fc4c f5eec00a   vcmpe.f32    s1, #0
00147c50 1016fc50 10b5       push         {r4, lr}
00147c52 1016fc52 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147c56 1016fc56 0c46       mov          r4, r1
00147c58 1016fc58 2ded048b   vpush        {d8, d9}
00147c5c 1016fc5c 45d9       bls          #0x1016fcea
00147c5e 1016fc5e b6ee007a   vmov.f32     s14, #5.000000e-01
00147c62 1016fc62 f4eec70a   vcmpe.f32    s1, s14
00147c66 1016fc66 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147c6a 1016fc6a 3eda       bge          #0x1016fcea
00147c6c 1016fc6c 0028       cmp          r0, #0
00147c6e 1016fc6e 4ed0       beq          #0x1016fd0e
00147c70 1016fc70 0128       cmp          r0, #1
00147c72 1016fc72 53d0       beq          #0x1016fd1c
00147c74 1016fc74 0228       cmp          r0, #2
00147c76 1016fc76 58d0       beq          #0x1016fd2a
00147c78 1016fc78 0328       cmp          r0, #3
00147c7a 1016fc7a 5dd0       beq          #0x1016fd38
00147c7c 1016fc7c 0428       cmp          r0, #4
00147c7e 1016fc7e 62d0       beq          #0x1016fd46
00147c80 1016fc80 0528       cmp          r0, #5
00147c82 1016fc82 67d1       bne          #0x1016fd54
00147c84 1016fc84 9fed368a   vldr         s16, [pc, #0xd8] ; literal raw=0x147d60: 0x40c90fdb
00147c88 1016fc88 f0ee418a   vmov.f32     s17, s2
00147c8c 1016fc8c b7ee009a   vmov.f32     s18, #1.000000e+00
00147c90 1016fc90 20ee888a   vmul.f32     s16, s1, s16
00147c94 1016fc94 b0ee480a   vmov.f32     s0, s16
00147c98 1016fc98 52f1eafa   bl           #0x102c2270
00147c9c 1016fc9c 38eea81a   vadd.f32     s2, s17, s17
00147ca0 1016fca0 f0ee407a   vmov.f32     s15, s0
00147ca4 1016fca4 b0ee480a   vmov.f32     s0, s16
00147ca8 1016fca8 87ee818a   vdiv.f32     s16, s15, s2
00147cac 1016fcac 50f180fd   bl           #0x102c07b0
00147cb0 1016fcb0 84ed009a   vstr         s18, [r4]
00147cb4 1016fcb4 f8ee007a   vmov.f32     s15, #-2.000000e+00
00147cb8 1016fcb8 20ee270a   vmul.f32     s0, s0, s15
00147cbc 1016fcbc 78ee097a   vadd.f32     s15, s16, s18
00147cc0 1016fcc0 39ee489a   vsub.f32     s18, s18, s16
00147cc4 1016fcc4 80ee277a   vdiv.f32     s14, s0, s15
00147cc8 1016fcc8 c9ee276a   vdiv.f32     s13, s18, s15
00147ccc 1016fccc 87eea76a   vdiv.f32     s12, s15, s15
00147cd0 1016fcd0 84ed017a   vstr         s14, [r4, #4]
00147cd4 1016fcd4 84ed047a   vstr         s14, [r4, #0x10]
00147cd8 1016fcd8 c4ed026a   vstr         s13, [r4, #8]
00147cdc 1016fcdc c4ed036a   vstr         s13, [r4, #0xc]
00147ce0 1016fce0 84ed056a   vstr         s12, [r4, #0x14]
00147ce4 1016fce4 bdec048b   vpop         {d8, d9}
00147ce8 1016fce8 10bd       pop          {r4, pc}
00147cea 1016fcea 0023       movs         r3, #0
00147cec 1016fcec 4ff07e50   mov.w        r0, #0x3f800000
00147cf0 1016fcf0 1c4a       ldr          r2, [pc, #0x70] ; literal raw=0x147d64: 0x10787d04 iir_coefs_generate
00147cf2 1016fcf2 2060       str          r0, [r4]
00147cf4 1016fcf4 e060       str          r0, [r4, #0xc]
00147cf6 1016fcf6 4120       movs         r0, #0x41
00147cf8 1016fcf8 6360       str          r3, [r4, #4]
00147cfa 1016fcfa a360       str          r3, [r4, #8]
00147cfc 1016fcfc 2361       str          r3, [r4, #0x10]
00147cfe 1016fcfe 6361       str          r3, [r4, #0x14]
00147d00 1016fd00 1949       ldr          r1, [pc, #0x64] ; literal raw=0x147d68: 0x10787c00 [%s] center frequency is above nyquist frequency, skip this band
00147d02 1016fd02 bdec048b   vpop         {d8, d9}
00147d06 1016fd06 bde81040   pop.w        {r4, lr}
00147d0a 1016fd0a d0f7fdba   b.w          #0x10140308
00147d0e 1016fd0e bdec048b   vpop         {d8, d9}
00147d12 1016fd12 0846       mov          r0, r1
00147d14 1016fd14 bde81040   pop.w        {r4, lr}
00147d18 1016fd18 fff72ebd   b.w          #0x1016f778
00147d1c 1016fd1c bdec048b   vpop         {d8, d9}
00147d20 1016fd20 0846       mov          r0, r1
00147d22 1016fd22 bde81040   pop.w        {r4, lr}
00147d26 1016fd26 fff7a3be   b.w          #0x1016fa70
00147d2a 1016fd2a bdec048b   vpop         {d8, d9}
00147d2e 1016fd2e 0846       mov          r0, r1
00147d30 1016fd30 bde81040   pop.w        {r4, lr}
00147d34 1016fd34 fff7dabd   b.w          #0x1016f8ec
00147d38 1016fd38 bdec048b   vpop         {d8, d9}
00147d3c 1016fd3c 0846       mov          r0, r1
00147d3e 1016fd3e bde81040   pop.w        {r4, lr}
00147d42 1016fd42 fff737bf   b.w          #0x1016fbb4
00147d46 1016fd46 bdec048b   vpop         {d8, d9}
00147d4a 1016fd4a 0846       mov          r0, r1
00147d4c 1016fd4c bde81040   pop.w        {r4, lr}
00147d50 1016fd50 fff7ecbe   b.w          #0x1016fb2c
00147d54 1016fd54 0246       mov          r2, r0
00147d56 1016fd56 0549       ldr          r1, [pc, #0x14] ; literal raw=0x147d6c: 0x10787d44 iir_coefs_generate
00147d58 1016fd58 0548       ldr          r0, [pc, #0x14] ; literal raw=0x147d70: 0x10787c44 [%s] %d is not supported
00147d5a 1016fd5a d0f781fd   bl           #0x10140860
00147d5e 1016fd5e 00bf       nop          
00147d60 1016fd60 db0f       lsrs         r3, r3, #0x1f
00147d62 1016fd62 c940       lsrs         r1, r1
00147d64 1016fd64 047d       ldrb         r4, [r0, #0x14]
00147d66 1016fd66 7810       asrs         r0, r7, #1
00147d68 1016fd68 007c       ldrb         r0, [r0, #0x10]
00147d6a 1016fd6a 7810       asrs         r0, r7, #1
00147d6c 1016fd6c 447d       ldrb         r4, [r0, #0x15]
00147d6e 1016fd6e 7810       asrs         r0, r7, #1
00147d70 1016fd70 447c       ldrb         r4, [r0, #0x11]
00147d72 1016fd72 7810       asrs         r0, r7, #1
00147d74 1016fd74 0000       movs         r0, r0
00147d76 1016fd76 0000       movs         r0, r0
00147d78 1016fd78 2de9f041   push.w       {r4, r5, r6, r7, r8, lr}
00147d7c 1016fd7c ca4b       ldr          r3, [pc, #0x328] ; literal raw=0x1480a8: 0x201a0b50
00147d7e 1016fd7e 0446       mov          r4, r0
00147d80 1016fd80 ca4e       ldr          r6, [pc, #0x328] ; literal raw=0x1480ac: 0x20240fdc
00147d82 1016fd82 0127       movs         r7, #1
00147d84 1016fd84 0d46       mov          r5, r1
00147d86 1016fd86 ca4a       ldr          r2, [pc, #0x328] ; literal raw=0x1480b0: 0x10787d2c hw_codec_iir_get_cfg
00147d88 1016fd88 ca49       ldr          r1, [pc, #0x328] ; literal raw=0x1480b4: 0x10787c60
00147d8a 1016fd8a 4220       movs         r0, #0x42
00147d8c 1016fd8c 2ded088b   vpush        {d8, d9, d10, d11}
00147d90 1016fd90 8eb0       sub          sp, #0x38
00147d92 1016fd92 1b68       ldr          r3, [r3]
00147d94 1016fd94 0d93       str          r3, [sp, #0x34]
00147d96 1016fd96 4ff00003   mov.w        r3, #0
00147d9a 1016fd9a 2346       mov          r3, r4
00147d9c 1016fd9c d0f7b4fa   bl           #0x10140308
00147da0 1016fda0 3780       strh         r7, [r6]
00147da2 1016fda2 a6f8c473   strh.w       r7, [r6, #0x3c4]
00147da6 1016fda6 002d       cmp          r5, #0
00147da8 1016fda8 00f0bb81   beq.w        #0x10170122
00147dac 1016fdac aa68       ldr          r2, [r5, #8]
00147dae 1016fdae 282a       cmp          r2, #0x28
00147db0 1016fdb0 00f3bf81   bgt.w        #0x10170132
00147db4 1016fdb4 b3ee048a   vmov.f32     s16, #2.000000e+01
00147db8 1016fdb8 d5ed000a   vldr         s1, [r5]
00147dbc 1016fdbc b2ee040a   vmov.f32     s0, #1.000000e+01
00147dc0 1016fdc0 c0ee880a   vdiv.f32     s1, s1, s16
00147dc4 1016fdc4 52f1c0f8   bl           #0x102c1f48
00147dc8 1016fdc8 d5ed010a   vldr         s1, [r5, #4]
00147dcc 1016fdcc f0ee408a   vmov.f32     s17, s0
00147dd0 1016fdd0 c0ee880a   vdiv.f32     s1, s1, s16
00147dd4 1016fdd4 b2ee040a   vmov.f32     s0, #1.000000e+01
00147dd8 1016fdd8 52f1b6f8   bl           #0x102c1f48
00147ddc 1016fddc ab68       ldr          r3, [r5, #8]
00147dde 1016fdde b44a       ldr          r2, [pc, #0x2d0] ; literal raw=0x1480b0: 0x10787d2c hw_codec_iir_get_cfg
00147de0 1016fde0 4220       movs         r0, #0x42
00147de2 1016fde2 b549       ldr          r1, [pc, #0x2d4] ; literal raw=0x1480b8: 0x10787cb4 [%s] len = %d
00147de4 1016fde4 b0ee40ba   vmov.f32     s22, s0
00147de8 1016fde8 d0f78efa   bl           #0x10140308
00147dec 1016fdec 4ff4f162   mov.w        r2, #0x788
00147df0 1016fdf0 0021       movs         r1, #0
00147df2 1016fdf2 3046       mov          r0, r6
00147df4 1016fdf4 5cf140f8   bl           #0x102cbe78
00147df8 1016fdf8 aa68       ldr          r2, [r5, #8]
00147dfa 1016fdfa 002a       cmp          r2, #0
00147dfc 1016fdfc 00f0ef80   beq.w        #0x1016ffde
00147e00 1016fe00 40f3e080   ble.w        #0x1016ffc4
00147e04 1016fe04 07ee904a   vmov         s15, r4
00147e08 1016fe08 2f46       mov          r7, r5
00147e0a 1016fe0a 3446       mov          r4, r6
00147e0c 1016fe0c 4ff00008   mov.w        r8, #0
00147e10 1016fe10 f8eee7ba   vcvt.f32.s32 s23, s15
00147e14 1016fe14 9feda98a   vldr         s16, [pc, #0x2a4] ; literal raw=0x1480bc: 0x417e6666
00147e18 1016fe18 9feda19b   vldr         d9, [pc, #0x284] ; literal raw=0x1480a0: 0x00000000
00147e1c 1016fe1c d7ed050a   vldr         s1, [r7, #0x14]
00147e20 1016fe20 01a9       add          r1, sp, #4
00147e22 1016fe22 97ed061a   vldr         s2, [r7, #0x18]
00147e26 1016fe26 c0eeab0a   vdiv.f32     s1, s1, s23
00147e2a 1016fe2a 97ed040a   vldr         s0, [r7, #0x10]
00147e2e 1016fe2e 387b       ldrb         r0, [r7, #0xc]
00147e30 1016fe30 fff70cff   bl           #0x1016fc4c
00147e34 1016fe34 9ded017a   vldr         s14, [sp, #4]
00147e38 1016fe38 9ded025a   vldr         s10, [sp, #8]
00147e3c 1016fe3c 9ded036a   vldr         s12, [sp, #0xc]
00147e40 1016fe40 dded045a   vldr         s11, [sp, #0x10]
00147e44 1016fe44 dded056a   vldr         s13, [sp, #0x14]
00147e48 1016fe48 dded067a   vldr         s15, [sp, #0x18]
00147e4c 1016fe4c 8ded077a   vstr         s14, [sp, #0x1c]
00147e50 1016fe50 8ded085a   vstr         s10, [sp, #0x20]
00147e54 1016fe54 8ded096a   vstr         s12, [sp, #0x24]
00147e58 1016fe58 cded0a5a   vstr         s11, [sp, #0x28]
00147e5c 1016fe5c cded0b6a   vstr         s13, [sp, #0x2c]
00147e60 1016fe60 cded0c7a   vstr         s15, [sp, #0x30]
00147e64 1016fe64 b8f1000f   cmp.w        r8, #0
00147e68 1016fe68 17d1       bne          #0x1016fe9a
00147e6a 1016fe6a 65eea83a   vmul.f32     s7, s11, s17
00147e6e 1016fe6e 26eea84a   vmul.f32     s8, s13, s17
00147e72 1016fe72 67eea84a   vmul.f32     s9, s15, s17
00147e76 1016fe76 65ee8b5a   vmul.f32     s11, s11, s22
00147e7a 1016fe7a cded043a   vstr         s7, [sp, #0x10]
00147e7e 1016fe7e 66ee8b6a   vmul.f32     s13, s13, s22
00147e82 1016fe82 8ded054a   vstr         s8, [sp, #0x14]
00147e86 1016fe86 67ee8b7a   vmul.f32     s15, s15, s22
00147e8a 1016fe8a cded064a   vstr         s9, [sp, #0x18]
00147e8e 1016fe8e cded0a5a   vstr         s11, [sp, #0x28]
00147e92 1016fe92 cded0b6a   vstr         s13, [sp, #0x2c]
00147e96 1016fe96 cded0c7a   vstr         s15, [sp, #0x30]
00147e9a 1016fe9a fbee006a   vmov.f32     s13, #-1.600000e+01
00147e9e 1016fe9e 02ab       add          r3, sp, #8
00147ea0 1016fea0 f0ee477a   vmov.f32     s15, s14
00147ea4 1016fea4 0022       movs         r2, #0
00147ea6 1016fea6 01e0       b            #0x1016feac
00147ea8 1016fea8 f3ec017a   vldmia       r3!, {s15}
00147eac 1016feac f4eee67a   vcmpe.f32    s15, s13
00147eb0 1016feb0 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147eb4 1016feb4 40f32881   ble.w        #0x10170108
00147eb8 1016feb8 f4eec87a   vcmpe.f32    s15, s16
00147ebc 1016febc f1ee10fa   vmrs         apsr_nzcv, fpscr
00147ec0 1016fec0 40f12281   bpl.w        #0x10170108
00147ec4 1016fec4 0132       adds         r2, #1
00147ec6 1016fec6 062a       cmp          r2, #6
00147ec8 1016fec8 eed1       bne          #0x1016fea8
00147eca 1016feca fbee006a   vmov.f32     s13, #-1.600000e+01
00147ece 1016fece 08ab       add          r3, sp, #0x20
00147ed0 1016fed0 f0ee477a   vmov.f32     s15, s14
00147ed4 1016fed4 0022       movs         r2, #0
00147ed6 1016fed6 01e0       b            #0x1016fedc
00147ed8 1016fed8 f3ec017a   vldmia       r3!, {s15}
00147edc 1016fedc f4eee67a   vcmpe.f32    s15, s13
00147ee0 1016fee0 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147ee4 1016fee4 40f31081   ble.w        #0x10170108
00147ee8 1016fee8 f4eec87a   vcmpe.f32    s15, s16
00147eec 1016feec f1ee10fa   vmrs         apsr_nzcv, fpscr
00147ef0 1016fef0 40f10a81   bpl.w        #0x10170108
00147ef4 1016fef4 0132       adds         r2, #1
00147ef6 1016fef6 062a       cmp          r2, #6
00147ef8 1016fef8 eed1       bne          #0x1016fed8
00147efa 1016fefa b7eec77a   vcvt.f64.f32 d7, s14
00147efe 1016fefe 9ded04aa   vldr         s20, [sp, #0x10]
00147f02 1016ff02 b7eec55a   vcvt.f64.f32 d5, s10
00147f06 1016ff06 9ded051a   vldr         s2, [sp, #0x14]
00147f0a 1016ff0a b7eec66a   vcvt.f64.f32 d6, s12
00147f0e 1016ff0e 9ded0a0a   vldr         s0, [sp, #0x28]
00147f12 1016ff12 27ee097b   vmul.f64     d7, d7, d9
00147f16 1016ff16 9ded0b2a   vldr         s4, [sp, #0x2c]
00147f1a 1016ff1a 9ded064a   vldr         s8, [sp, #0x18]
00147f1e 1016ff1e 08f10108   add.w        r8, r8, #1
00147f22 1016ff22 9ded0c3a   vldr         s6, [sp, #0x30]
00147f26 1016ff26 1037       adds         r7, #0x10
00147f28 1016ff28 25ee095b   vmul.f64     d5, d5, d9
00147f2c 1016ff2c b7eecaaa   vcvt.f64.f32 d10, s20
00147f30 1016ff30 b7eec11a   vcvt.f64.f32 d1, s2
00147f34 1016ff34 b7eec00a   vcvt.f64.f32 d0, s0
00147f38 1016ff38 b7eec22a   vcvt.f64.f32 d2, s4
00147f3c 1016ff3c fdeec77b   vcvt.s32.f64 s15, d7
00147f40 1016ff40 26ee096b   vmul.f64     d6, d6, d9
00147f44 1016ff44 17ee901a   vmov         r1, s15
00147f48 1016ff48 b7eec44a   vcvt.f64.f32 d4, s8
00147f4c 1016ff4c b7eec33a   vcvt.f64.f32 d3, s6
00147f50 1016ff50 2161       str          r1, [r4, #0x10]
00147f52 1016ff52 2aee09ab   vmul.f64     d10, d10, d9
00147f56 1016ff56 c4f8d413   str.w        r1, [r4, #0x3d4]
00147f5a 1016ff5a 21ee091b   vmul.f64     d1, d1, d9
00147f5e 1016ff5e 20ee090b   vmul.f64     d0, d0, d9
00147f62 1016ff62 22ee092b   vmul.f64     d2, d2, d9
00147f66 1016ff66 fdeec57b   vcvt.s32.f64 s15, d5
00147f6a 1016ff6a 24ee094b   vmul.f64     d4, d4, d9
00147f6e 1016ff6e 17ee902a   vmov         r2, s15
00147f72 1016ff72 23ee093b   vmul.f64     d3, d3, d9
00147f76 1016ff76 c4f8d823   str.w        r2, [r4, #0x3d8]
00147f7a 1016ff7a fdeec67b   vcvt.s32.f64 s15, d6
00147f7e 1016ff7e bdeecaab   vcvt.s32.f64 s20, d10
00147f82 1016ff82 bdeec00b   vcvt.s32.f64 s0, d0
00147f86 1016ff86 bdeec11b   vcvt.s32.f64 s2, d1
00147f8a 1016ff8a 17ee903a   vmov         r3, s15
00147f8e 1016ff8e bdeec22b   vcvt.s32.f64 s4, d2
00147f92 1016ff92 84ed01aa   vstr         s20, [r4, #4]
00147f96 1016ff96 bdeec33b   vcvt.s32.f64 s6, d3
00147f9a 1016ff9a c4edf77a   vstr         s15, [r4, #0x3dc]
00147f9e 1016ff9e bdeec44b   vcvt.s32.f64 s8, d4
00147fa2 1016ffa2 84edf20a   vstr         s0, [r4, #0x3c8]
00147fa6 1016ffa6 84ed021a   vstr         s2, [r4, #8]
00147faa 1016ffaa 84edf32a   vstr         s4, [r4, #0x3cc]
00147fae 1016ffae c4e90523   strd         r2, r3, [r4, #0x14]
00147fb2 1016ffb2 84edf43a   vstr         s6, [r4, #0x3d0]
00147fb6 1016ffb6 1834       adds         r4, #0x18
00147fb8 1016ffb8 04ed034a   vstr         s8, [r4, #-0xc]
00147fbc 1016ffbc aa68       ldr          r2, [r5, #8]
00147fbe 1016ffbe 4245       cmp          r2, r8
00147fc0 1016ffc0 3ff72caf   bgt.w        #0x1016fe1c
00147fc4 1016ffc4 002a       cmp          r2, #0
00147fc6 1016ffc6 c0f29d80   blt.w        #0x10170104
00147fca 1016ffca 0022       movs         r2, #0
00147fcc 1016ffcc 3748       ldr          r0, [pc, #0xdc] ; literal raw=0x1480ac: 0x20240fdc
00147fce 1016ffce a6f8c423   strh.w       r2, [r6, #0x3c4]
00147fd2 1016ffd2 2b89       ldrh         r3, [r5, #8]
00147fd4 1016ffd4 3280       strh         r2, [r6]
00147fd6 1016ffd6 7380       strh         r3, [r6, #2]
00147fd8 1016ffd8 a6f8c633   strh.w       r3, [r6, #0x3c6]
00147fdc 1016ffdc 14e0       b            #0x10170008
00147fde 1016ffde d5ed007a   vldr         s15, [r5]
00147fe2 1016ffe2 0021       movs         r1, #0
00147fe4 1016ffe4 f5ee407a   vcmp.f32     s15, #0
00147fe8 1016ffe8 f1ee10fa   vmrs         apsr_nzcv, fpscr
00147fec 1016ffec 19d1       bne          #0x10170022
00147fee 1016ffee 3780       strh         r7, [r6]
00147ff0 1016fff0 d5ed017a   vldr         s15, [r5, #4]
00147ff4 1016fff4 0021       movs         r1, #0
00147ff6 1016fff6 f5ee407a   vcmp.f32     s15, #0
00147ffa 1016fffa f1ee10fa   vmrs         apsr_nzcv, fpscr
00147ffe 1016fffe 3ed1       bne          #0x1017007e
00148000 10170000 0123       movs         r3, #1
00148002 10170002 2a48       ldr          r0, [pc, #0xa8] ; literal raw=0x1480ac: 0x20240fdc
00148004 10170004 a6f8c433   strh.w       r3, [r6, #0x3c4]
00148008 10170008 274b       ldr          r3, [pc, #0x9c] ; literal raw=0x1480a8: 0x201a0b50
0014800a 1017000a 1a68       ldr          r2, [r3]
0014800c 1017000c 0d9b       ldr          r3, [sp, #0x34]
0014800e 1017000e 5a40       eors         r2, r3
00148010 10170010 4ff00003   mov.w        r3, #0
00148014 10170014 40f08b80   bne.w        #0x1017012e
00148018 10170018 0eb0       add          sp, #0x38
0014801a 1017001a bdec088b   vpop         {d8, d9, d10, d11}
0014801e 1017001e bde8f081   pop.w        {r4, r5, r6, r7, r8, pc}
00148022 10170022 4ff07e53   mov.w        r3, #0x3f800000
00148026 10170026 fbee006a   vmov.f32     s13, #-1.600000e+01
0014802a 1017002a 9fed247a   vldr         s14, [pc, #0x90] ; literal raw=0x1480bc: 0x417e6666
0014802e 1017002e 0193       str          r3, [sp, #4]
00148030 10170030 02ab       add          r3, sp, #8
00148032 10170032 0291       str          r1, [sp, #8]
00148034 10170034 0391       str          r1, [sp, #0xc]
00148036 10170036 cded048a   vstr         s17, [sp, #0x10]
0014803a 1017003a 0591       str          r1, [sp, #0x14]
0014803c 1017003c 0691       str          r1, [sp, #0x18]
0014803e 1017003e 0be0       b            #0x10170058
00148040 10170040 f3ec017a   vldmia       r3!, {s15}
00148044 10170044 f4eee67a   vcmpe.f32    s15, s13
00148048 10170048 f1ee10fa   vmrs         apsr_nzcv, fpscr
0014804c 1017004c 5cdd       ble          #0x10170108
0014804e 1017004e f4eec77a   vcmpe.f32    s15, s14
00148052 10170052 f1ee10fa   vmrs         apsr_nzcv, fpscr
00148056 10170056 57d5       bpl          #0x10170108
00148058 10170058 0132       adds         r2, #1
0014805a 1017005a 062a       cmp          r2, #6
0014805c 1017005c f0d1       bne          #0x10170040
0014805e 1017005e b7eee87a   vcvt.f64.f32 d7, s17
00148062 10170062 4ff00062   mov.w        r2, #0x8000000
00148066 10170066 0123       movs         r3, #1
00148068 10170068 3261       str          r2, [r6, #0x10]
0014806a 1017006a 7380       strh         r3, [r6, #2]
0014806c 1017006c 9fed0c6b   vldr         d6, [pc, #0x30] ; literal raw=0x1480a0: 0x00000000
00148070 10170070 27ee067b   vmul.f64     d7, d7, d6
00148074 10170074 bdeec77b   vcvt.s32.f64 s14, d7
00148078 10170078 86ed017a   vstr         s14, [r6, #4]
0014807c 1017007c b8e7       b            #0x1016fff0
0014807e 1017007e 4ff07e50   mov.w        r0, #0x3f800000
00148082 10170082 fbee006a   vmov.f32     s13, #-1.600000e+01
00148086 10170086 08ab       add          r3, sp, #0x20
00148088 10170088 0022       movs         r2, #0
0014808a 1017008a 9fed0c7a   vldr         s14, [pc, #0x30] ; literal raw=0x1480bc: 0x417e6666
0014808e 1017008e 0891       str          r1, [sp, #0x20]
00148090 10170090 0790       str          r0, [sp, #0x1c]
00148092 10170092 0991       str          r1, [sp, #0x24]
00148094 10170094 8ded0aba   vstr         s22, [sp, #0x28]
00148098 10170098 0b91       str          r1, [sp, #0x2c]
0014809a 1017009a 0c91       str          r1, [sp, #0x30]
0014809c 1017009c 1ce0       b            #0x101700d8
0014809e 1017009e 00bf       nop          
001480a0 101700a0 0000       movs         r0, r0
001480a2 101700a2 0000       movs         r0, r0
001480a4 101700a4 0000       movs         r0, r0
001480a6 101700a6 a041       sbcs         r0, r4
001480a8 101700a8 500b       lsrs         r0, r2, #0xd
001480aa 101700aa 1a20       movs         r0, #0x1a
001480ac 101700ac dc0f       lsrs         r4, r3, #0x1f
001480ae 101700ae 2420       movs         r0, #0x24
001480b0 101700b0 2c7d       ldrb         r4, [r5, #0x14]
001480b2 101700b2 7810       asrs         r0, r7, #1
001480b4 101700b4 607c       ldrb         r0, [r4, #0x11]
001480b6 101700b6 7810       asrs         r0, r7, #1
001480b8 101700b8 b47c       ldrb         r4, [r6, #0x12]
001480ba 101700ba 7810       asrs         r0, r7, #1
001480bc 101700bc 6666       str          r6, [r4, #0x64]
001480be 101700be 7e41       adcs         r6, r7
001480c0 101700c0 f3ec017a   vldmia       r3!, {s15}
001480c4 101700c4 f4eee67a   vcmpe.f32    s15, s13
001480c8 101700c8 f1ee10fa   vmrs         apsr_nzcv, fpscr
001480cc 101700cc 1cdd       ble          #0x10170108
001480ce 101700ce f4eec77a   vcmpe.f32    s15, s14
001480d2 101700d2 f1ee10fa   vmrs         apsr_nzcv, fpscr
001480d6 101700d6 17d5       bpl          #0x10170108
001480d8 101700d8 0132       adds         r2, #1
001480da 101700da 062a       cmp          r2, #6
001480dc 101700dc f0d1       bne          #0x101700c0
001480de 101700de b7eecb7a   vcvt.f64.f32 d7, s22
001480e2 101700e2 4ff00062   mov.w        r2, #0x8000000
001480e6 101700e6 0123       movs         r3, #1
001480e8 101700e8 1748       ldr          r0, [pc, #0x5c] ; literal raw=0x148148: 0x20240fdc
001480ea 101700ea c6f8d423   str.w        r2, [r6, #0x3d4]
001480ee 101700ee a6f8c633   strh.w       r3, [r6, #0x3c6]
001480f2 101700f2 9fed136b   vldr         d6, [pc, #0x4c] ; literal raw=0x148140: 0x00000000
001480f6 101700f6 27ee067b   vmul.f64     d7, d7, d6
001480fa 101700fa bdeec77b   vcvt.s32.f64 s14, d7
001480fe 101700fe 86ed       .byte        0x86, 0xed
