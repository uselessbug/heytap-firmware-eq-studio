0014a400 10172400 48aa       add          r2, sp, #0x120
0014a402 10172402 37ee077a   vadd.f32     s14, s14, s14
0014a406 10172406 f8ee007a   vmov.f32     s15, #-2.000000e+00
0014a40a 1017240a b0ee490a   vmov.f32     s0, s18
0014a40e 1017240e abee07aa   vfma.f32     s20, s22, s14
0014a412 10172412 69ee277a   vmul.f32     s15, s18, s15
0014a416 10172416 67eea88a   vmul.f32     s17, s15, s17
0014a41a 1017241a 52f1c3fe   bl           #0x102c51a4
0014a41e 1017241e dded016a   vldr         s13, [sp, #4]
0014a422 10172422 70ee007a   vadd.f32     s15, s0, s0
0014a426 10172426 29ee0aaa   vmul.f32     s20, s18, s20
0014a42a 1017242a 9ce7       b            #0x10172366
0014a42c 1017242c db0f       lsrs         r3, r3, #0x1f
0014a42e 1017242e c940       lsrs         r1, r1
0014a430 10172430 b0ee407a   vmov.f32     s14, s0
0014a434 10172434 f3ee047a   vmov.f32     s15, #2.000000e+01
0014a438 10172438 b2ee040a   vmov.f32     s0, #1.000000e+01
0014a43c 1017243c 10b5       push         {r4, lr}
0014a43e 1017243e 2ded048b   vpush        {d8, d9}
0014a442 10172442 b0ee609a   vmov.f32     s18, s1
0014a446 10172446 0446       mov          r4, r0
0014a448 10172448 c7ee270a   vdiv.f32     s1, s14, s15
0014a44c 1017244c f0ee418a   vmov.f32     s17, s2
0014a450 10172450 52f13afb   bl           #0x102c4ac8
0014a454 10172454 b5ee400a   vcmp.f32     s0, #0
0014a458 10172458 f1ee10fa   vmrs         apsr_nzcv, fpscr
0014a45c 1017245c 3ed4       bmi          #0x101724dc
0014a45e 1017245e f1eec09a   vsqrt.f32    s19, s0
0014a462 10172462 dfed217a   vldr         s15, [pc, #0x84] ; literal raw=0x14a4e8: 0x40c90fdb
0014a466 10172466 29ee279a   vmul.f32     s18, s18, s15
0014a46a 1017246a 78eea88a   vadd.f32     s17, s17, s17
0014a46e 1017246e b7ee008a   vmov.f32     s16, #1.000000e+00
0014a472 10172472 b0ee490a   vmov.f32     s0, s18
0014a476 10172476 52f1bbfc   bl           #0x102c4df0
0014a47a 1017247a f0ee407a   vmov.f32     s15, s0
0014a47e 1017247e b0ee490a   vmov.f32     s0, s18
0014a482 10172482 87eea89a   vdiv.f32     s18, s15, s17
0014a486 10172486 50f153ff   bl           #0x102c3330
0014a48a 1017248a 84ed008a   vstr         s16, [r4]
0014a48e 1017248e f0ee486a   vmov.f32     s13, s16
0014a492 10172492 b0ee485a   vmov.f32     s10, s16
0014a496 10172496 f8ee007a   vmov.f32     s15, #-2.000000e+00
0014a49a 1017249a 20ee270a   vmul.f32     s0, s0, s15
0014a49e 1017249e 89ee297a   vdiv.f32     s14, s18, s19
0014a4a2 101724a2 e9ee296a   vfma.f32     s13, s18, s19
0014a4a6 101724a6 a9ee695a   vfms.f32     s10, s18, s19
0014a4aa 101724aa 77ee087a   vadd.f32     s15, s14, s16
0014a4ae 101724ae 38ee478a   vsub.f32     s16, s16, s14
0014a4b2 101724b2 86eea76a   vdiv.f32     s12, s13, s15
0014a4b6 101724b6 80ee277a   vdiv.f32     s14, s0, s15
0014a4ba 101724ba c8ee275a   vdiv.f32     s11, s16, s15
0014a4be 101724be c5ee276a   vdiv.f32     s13, s10, s15
0014a4c2 101724c2 84ed036a   vstr         s12, [r4, #0xc]
0014a4c6 101724c6 84ed017a   vstr         s14, [r4, #4]
0014a4ca 101724ca 84ed047a   vstr         s14, [r4, #0x10]
0014a4ce 101724ce c4ed025a   vstr         s11, [r4, #8]
0014a4d2 101724d2 c4ed056a   vstr         s13, [r4, #0x14]
0014a4d6 101724d6 bdec048b   vpop         {d8, d9}
0014a4da 101724da 10bd       pop          {r4, pc}
0014a4dc 101724dc 52f162fe   bl           #0x102c51a4
0014a4e0 101724e0 f0ee409a   vmov.f32     s19, s0
0014a4e4 101724e4 bde7       b            #0x10172462
0014a4e6 101724e6 00bf       nop          
0014a4e8 101724e8 db0f       lsrs         r3, r3, #0x1f
0014a4ea 101724ea c940       lsrs         r1, r1
0014a4ec 101724ec 10b5       push         {r4, lr}
0014a4ee 101724ee 2ded048b   vpush        {d8, d9}
0014a4f2 101724f2 9fed1f9a   vldr         s18, [pc, #0x7c] ; literal raw=0x14a570: 0x40c90fdb
0014a4f6 101724f6 f0ee418a   vmov.f32     s17, s2
0014a4fa 101724fa 0446       mov          r4, r0
0014a4fc 101724fc b7ee008a   vmov.f32     s16, #1.000000e+00
0014a500 10172500 20ee899a   vmul.f32     s18, s1, s18
0014a504 10172504 78eea88a   vadd.f32     s17, s17, s17
0014a508 10172508 b0ee490a   vmov.f32     s0, s18
0014a50c 1017250c 52f170fc   bl           #0x102c4df0
0014a510 10172510 f0ee407a   vmov.f32     s15, s0
0014a514 10172514 b0ee490a   vmov.f32     s0, s18
0014a518 10172518 87eea89a   vdiv.f32     s18, s15, s17
0014a51c 1017251c 50f108ff   bl           #0x102c3330
0014a520 10172520 84ed008a   vstr         s16, [r4]
0014a524 10172524 70ee087a   vadd.f32     s15, s0, s16
0014a528 10172528 f8ee006a   vmov.f32     s13, #-2.000000e+00
0014a52c 1017252c b6ee007a   vmov.f32     s14, #5.000000e-01
0014a530 10172530 20ee260a   vmul.f32     s0, s0, s13
0014a534 10172534 67ee876a   vmul.f32     s13, s15, s14
0014a538 10172538 b1ee677a   vneg.f32     s14, s15
0014a53c 1017253c 79ee087a   vadd.f32     s15, s18, s16
0014a540 10172540 38ee498a   vsub.f32     s16, s16, s18
0014a544 10172544 86eea76a   vdiv.f32     s12, s13, s15
0014a548 10172548 c8ee275a   vdiv.f32     s11, s16, s15
0014a54c 1017254c 80ee275a   vdiv.f32     s10, s0, s15
0014a550 10172550 c7ee276a   vdiv.f32     s13, s14, s15
0014a554 10172554 84ed036a   vstr         s12, [r4, #0xc]
0014a558 10172558 84ed056a   vstr         s12, [r4, #0x14]
0014a55c 1017255c c4ed025a   vstr         s11, [r4, #8]
0014a560 10172560 84ed015a   vstr         s10, [r4, #4]
0014a564 10172564 c4ed046a   vstr         s13, [r4, #0x10]
0014a568 10172568 bdec048b   vpop         {d8, d9}
0014a56c 1017256c 10bd       pop          {r4, pc}
0014a56e 1017256e 00bf       nop          
0014a570 10172570 db0f       lsrs         r3, r3, #0x1f
0014a572 10172572 c940       lsrs         r1, r1
0014a574 10172574 10b5       push         {r4, lr}
0014a576 10172576 2ded048b   vpush        {d8, d9}
0014a57a 1017257a 9fed1e9a   vldr         s18, [pc, #0x78] ; literal raw=0x14a5f4: 0x40c90fdb
0014a57e 1017257e f0ee418a   vmov.f32     s17, s2
0014a582 10172582 0446       mov          r4, r0
0014a584 10172584 b7ee008a   vmov.f32     s16, #1.000000e+00
0014a588 10172588 20ee899a   vmul.f32     s18, s1, s18
0014a58c 1017258c 78eea88a   vadd.f32     s17, s17, s17
0014a590 10172590 b0ee490a   vmov.f32     s0, s18
0014a594 10172594 52f12cfc   bl           #0x102c4df0
0014a598 10172598 f0ee407a   vmov.f32     s15, s0
0014a59c 1017259c b0ee490a   vmov.f32     s0, s18
0014a5a0 101725a0 87eea89a   vdiv.f32     s18, s15, s17
0014a5a4 101725a4 50f1c4fe   bl           #0x102c3330
0014a5a8 101725a8 84ed008a   vstr         s16, [r4]
0014a5ac 101725ac 38ee406a   vsub.f32     s12, s16, s0
0014a5b0 101725b0 b8ee007a   vmov.f32     s14, #-2.000000e+00
0014a5b4 101725b4 f6ee007a   vmov.f32     s15, #5.000000e-01
0014a5b8 101725b8 20ee070a   vmul.f32     s0, s0, s14
0014a5bc 101725bc 26ee277a   vmul.f32     s14, s12, s15
0014a5c0 101725c0 79ee087a   vadd.f32     s15, s18, s16
0014a5c4 101725c4 38ee498a   vsub.f32     s16, s16, s18
0014a5c8 101725c8 c7ee276a   vdiv.f32     s13, s14, s15
0014a5cc 101725cc c8ee275a   vdiv.f32     s11, s16, s15
0014a5d0 101725d0 80ee275a   vdiv.f32     s10, s0, s15
0014a5d4 101725d4 86ee277a   vdiv.f32     s14, s12, s15
0014a5d8 101725d8 c4ed036a   vstr         s13, [r4, #0xc]
0014a5dc 101725dc c4ed056a   vstr         s13, [r4, #0x14]
0014a5e0 101725e0 c4ed025a   vstr         s11, [r4, #8]
0014a5e4 101725e4 84ed015a   vstr         s10, [r4, #4]
0014a5e8 101725e8 84ed047a   vstr         s14, [r4, #0x10]
0014a5ec 101725ec bdec048b   vpop         {d8, d9}
0014a5f0 101725f0 10bd       pop          {r4, pc}
0014a5f2 101725f2 00bf       nop          
0014a5f4 101725f4 db0f       lsrs         r3, r3, #0x1f
0014a5f6 101725f6 c940       lsrs         r1, r1
0014a5f8 101725f8 f0ee400a   vmov.f32     s1, s0
0014a5fc 101725fc f3ee047a   vmov.f32     s15, #2.000000e+01
0014a600 10172600 b2ee040a   vmov.f32     s0, #1.000000e+01
0014a604 10172604 c0eea70a   vdiv.f32     s1, s1, s15
0014a608 10172608 52f15eba   b.w          #0x102c4ac8
0014a60c 1017260c f5eec00a   vcmpe.f32    s1, #0
0014a610 10172610 10b5       push         {r4, lr}
0014a612 10172612 f1ee10fa   vmrs         apsr_nzcv, fpscr
0014a616 10172616 0c46       mov          r4, r1
0014a618 10172618 2ded048b   vpush        {d8, d9}
0014a61c 1017261c 45d9       bls          #0x101726aa
0014a61e 1017261e b6ee007a   vmov.f32     s14, #5.000000e-01
0014a622 10172622 f4eec70a   vcmpe.f32    s1, s14
0014a626 10172626 f1ee10fa   vmrs         apsr_nzcv, fpscr
0014a62a 1017262a 3eda       bge          #0x101726aa
0014a62c 1017262c 0028       cmp          r0, #0
0014a62e 1017262e 4ed0       beq          #0x101726ce
0014a630 10172630 0128       cmp          r0, #1
0014a632 10172632 53d0       beq          #0x101726dc
0014a634 10172634 0228       cmp          r0, #2
0014a636 10172636 58d0       beq          #0x101726ea
0014a638 10172638 0328       cmp          r0, #3
0014a63a 1017263a 5dd0       beq          #0x101726f8
0014a63c 1017263c 0428       cmp          r0, #4
0014a63e 1017263e 62d0       beq          #0x10172706
0014a640 10172640 0528       cmp          r0, #5
0014a642 10172642 67d1       bne          #0x10172714
0014a644 10172644 9fed368a   vldr         s16, [pc, #0xd8] ; literal raw=0x14a720: 0x40c90fdb
0014a648 10172648 f0ee418a   vmov.f32     s17, s2
0014a64c 1017264c b7ee009a   vmov.f32     s18, #1.000000e+00
0014a650 10172650 20ee888a   vmul.f32     s16, s1, s16
0014a654 10172654 b0ee480a   vmov.f32     s0, s16
0014a658 10172658 52f1cafb   bl           #0x102c4df0
0014a65c 1017265c 38eea81a   vadd.f32     s2, s17, s17
0014a660 10172660 f0ee407a   vmov.f32     s15, s0
0014a664 10172664 b0ee480a   vmov.f32     s0, s16
0014a668 10172668 87ee818a   vdiv.f32     s16, s15, s2
0014a66c 1017266c 50f160fe   bl           #0x102c3330
0014a670 10172670 84ed009a   vstr         s18, [r4]
0014a674 10172674 f8ee007a   vmov.f32     s15, #-2.000000e+00
0014a678 10172678 20ee270a   vmul.f32     s0, s0, s15
0014a67c 1017267c 78ee097a   vadd.f32     s15, s16, s18
0014a680 10172680 39ee489a   vsub.f32     s18, s18, s16
0014a684 10172684 80ee277a   vdiv.f32     s14, s0, s15
0014a688 10172688 c9ee276a   vdiv.f32     s13, s18, s15
0014a68c 1017268c 87eea76a   vdiv.f32     s12, s15, s15
0014a690 10172690 84ed017a   vstr         s14, [r4, #4]
0014a694 10172694 84ed047a   vstr         s14, [r4, #0x10]
0014a698 10172698 c4ed026a   vstr         s13, [r4, #8]
0014a69c 1017269c c4ed036a   vstr         s13, [r4, #0xc]
0014a6a0 101726a0 84ed056a   vstr         s12, [r4, #0x14]
0014a6a4 101726a4 bdec048b   vpop         {d8, d9}
0014a6a8 101726a8 10bd       pop          {r4, pc}
0014a6aa 101726aa 0023       movs         r3, #0
0014a6ac 101726ac 4ff07e50   mov.w        r0, #0x3f800000
0014a6b0 101726b0 1c4a       ldr          r2, [pc, #0x70] ; literal raw=0x14a724: 0x107774a4 iir_coefs_generate
0014a6b2 101726b2 2060       str          r0, [r4]
0014a6b4 101726b4 e060       str          r0, [r4, #0xc]
0014a6b6 101726b6 4120       movs         r0, #0x41
0014a6b8 101726b8 6360       str          r3, [r4, #4]
0014a6ba 101726ba a360       str          r3, [r4, #8]
0014a6bc 101726bc 2361       str          r3, [r4, #0x10]
0014a6be 101726be 6361       str          r3, [r4, #0x14]
0014a6c0 101726c0 1949       ldr          r1, [pc, #0x64] ; literal raw=0x14a728: 0x107773a0 [%s] center frequency is above nyquist frequency, skip this band
0014a6c2 101726c2 bdec048b   vpop         {d8, d9}
0014a6c6 101726c6 bde81040   pop.w        {r4, lr}
0014a6ca 101726ca d0f7fdba   b.w          #0x10142cc8
0014a6ce 101726ce bdec048b   vpop         {d8, d9}
0014a6d2 101726d2 0846       mov          r0, r1
0014a6d4 101726d4 bde81040   pop.w        {r4, lr}
0014a6d8 101726d8 fff72ebd   b.w          #0x10172138
0014a6dc 101726dc bdec048b   vpop         {d8, d9}
0014a6e0 101726e0 0846       mov          r0, r1
0014a6e2 101726e2 bde81040   pop.w        {r4, lr}
0014a6e6 101726e6 fff7a3be   b.w          #0x10172430
0014a6ea 101726ea bdec048b   vpop         {d8, d9}
0014a6ee 101726ee 0846       mov          r0, r1
0014a6f0 101726f0 bde81040   pop.w        {r4, lr}
0014a6f4 101726f4 fff7dabd   b.w          #0x101722ac
0014a6f8 101726f8 bdec048b   vpop         {d8, d9}
0014a6fc 101726fc 0846       mov          r0, r1
0014a6fe 101726fe bde81040   pop.w        {r4, lr}
0014a702 10172702 fff737bf   b.w          #0x10172574
0014a706 10172706 bdec048b   vpop         {d8, d9}
0014a70a 1017270a 0846       mov          r0, r1
0014a70c 1017270c bde81040   pop.w        {r4, lr}
0014a710 10172710 fff7ecbe   b.w          #0x101724ec
0014a714 10172714 0246       mov          r2, r0
0014a716 10172716 0549       ldr          r1, [pc, #0x14] ; literal raw=0x14a72c: 0x107774e4 iir_coefs_generate
0014a718 10172718 0548       ldr          r0, [pc, #0x14] ; literal raw=0x14a730: 0x107773e4 [%s] %d is not supported
0014a71a 1017271a d0f781fd   bl           #0x10143220
0014a71e 1017271e 00bf       nop          
0014a720 10172720 db0f       lsrs         r3, r3, #0x1f
0014a722 10172722 c940       lsrs         r1, r1
0014a724 10172724 a474       strb         r4, [r4, #0x12]
0014a726 10172726 7710       asrs         r7, r6, #1
0014a728 10172728 a073       strb         r0, [r4, #0xe]
0014a72a 1017272a 7710       asrs         r7, r6, #1
0014a72c 1017272c e474       strb         r4, [r4, #0x13]
0014a72e 1017272e 7710       asrs         r7, r6, #1
