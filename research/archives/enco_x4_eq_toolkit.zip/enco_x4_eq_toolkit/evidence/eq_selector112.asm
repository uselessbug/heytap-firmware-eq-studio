000c3ac8 100ebac8 0228       cmp          r0, #2
000c3aca 100ebaca f8b5       push         {r3, r4, r5, r6, r7, lr}
000c3acc 100ebacc 0646       mov          r6, r0
000c3ace 100ebace 0f46       mov          r7, r1
000c3ad0 100ebad0 1446       mov          r4, r2
000c3ad2 100ebad2 4ff04000   mov.w        r0, #0x40
000c3ad6 100ebad6 14d0       beq          #0x100ebb02
000c3ad8 100ebad8 1749       ldr          r1, [pc, #0x5c] ; literal raw=0xc3b38: 0x1074a7d4 [ENCO EQM] eq_list_other
000c3ada 100ebada 54f015fc   bl           #0x10140308
000c3ade 100ebade 174d       ldr          r5, [pc, #0x5c] ; literal raw=0xc3b3c: 0x201e7e80
000c3ae0 100ebae0 174b       ldr          r3, [pc, #0x5c] ; literal raw=0xc3b40: 0x201e7d08
000c3ae2 100ebae2 3d60       str          r5, [r7]
000c3ae4 100ebae4 2360       str          r3, [r4]
000c3ae6 100ebae6 2b68       ldr          r3, [r5]
000c3ae8 100ebae8 03b3       cbz          r3, #0x100ebb2c
000c3aea 100ebaea 0024       movs         r4, #0
000c3aec 100ebaec 0134       adds         r4, #1
000c3aee 100ebaee e4b2       uxtb         r4, r4
000c3af0 100ebaf0 55f82430   ldr.w        r3, [r5, r4, lsl #2]
000c3af4 100ebaf4 002b       cmp          r3, #0
000c3af6 100ebaf6 f9d1       bne          #0x100ebaec
000c3af8 100ebaf8 3046       mov          r0, r6
000c3afa 100ebafa dff7d3fa   bl           #0x100cb0a4
000c3afe 100ebafe 2046       mov          r0, r4
000c3b00 100ebb00 f8bd       pop          {r3, r4, r5, r6, r7, pc}
000c3b02 100ebb02 1049       ldr          r1, [pc, #0x40] ; literal raw=0xc3b44: 0x1074a7b8 [ENCO EQM] eq_list_india
000c3b04 100ebb04 54f000fc   bl           #0x10140308
000c3b08 100ebb08 0f4a       ldr          r2, [pc, #0x3c] ; literal raw=0xc3b48: 0x201e7f3c
000c3b0a 100ebb0a 104b       ldr          r3, [pc, #0x40] ; literal raw=0xc3b4c: 0x201e7dc4
000c3b0c 100ebb0c 3a60       str          r2, [r7]
000c3b0e 100ebb0e 2360       str          r3, [r4]
000c3b10 100ebb10 1368       ldr          r3, [r2]
000c3b12 100ebb12 5bb1       cbz          r3, #0x100ebb2c
000c3b14 100ebb14 0024       movs         r4, #0
000c3b16 100ebb16 0134       adds         r4, #1
000c3b18 100ebb18 e4b2       uxtb         r4, r4
000c3b1a 100ebb1a 52f82430   ldr.w        r3, [r2, r4, lsl #2]
000c3b1e 100ebb1e 002b       cmp          r3, #0
000c3b20 100ebb20 f9d1       bne          #0x100ebb16
000c3b22 100ebb22 3046       mov          r0, r6
000c3b24 100ebb24 dff7befa   bl           #0x100cb0a4
000c3b28 100ebb28 2046       mov          r0, r4
000c3b2a 100ebb2a f8bd       pop          {r3, r4, r5, r6, r7, pc}
000c3b2c 100ebb2c 0024       movs         r4, #0
000c3b2e 100ebb2e 3046       mov          r0, r6
000c3b30 100ebb30 dff7b8fa   bl           #0x100cb0a4
000c3b34 100ebb34 2046       mov          r0, r4
000c3b36 100ebb36 f8bd       pop          {r3, r4, r5, r6, r7, pc}
000c3b38 100ebb38 d4a7       adr          r7, #0x350
000c3b3a 100ebb3a 7410       asrs         r4, r6, #1
000c3b3c 100ebb3c 807e       ldrb         r0, [r0, #0x1a]
000c3b3e 100ebb3e 1e20       movs         r0, #0x1e
000c3b40 100ebb40 087d       ldrb         r0, [r1, #0x14]
000c3b42 100ebb42 1e20       movs         r0, #0x1e
000c3b44 100ebb44 b8a7       adr          r7, #0x2e0
000c3b46 100ebb46 7410       asrs         r4, r6, #1
000c3b48 100ebb48 3c7f       ldrb         r4, [r7, #0x1c]
000c3b4a 100ebb4a 1e20       movs         r0, #0x1e
000c3b4c 100ebb4c c47d       ldrb         r4, [r0, #0x17]
000c3b4e 100ebb4e 1e20       movs         r0, #0x1e
