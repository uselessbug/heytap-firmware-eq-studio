00030e60 10058e60 4020       movs         r0, #0x40
00030e62 10058e62 0449       ldr          r1, [pc, #0x10] ; literal raw=0x30e74: 0x10707d68 [ENCO ACOUSTIC] enco_adapt_eq_tws_sync_handler, malloc err
00030e64 10058e64 03b0       add          sp, #0xc
00030e66 10058e66 bde83040   pop.w        {r4, r5, lr}
00030e6a 10058e6a e7f04dba   b.w          #0x10140308
00030e6e 10058e6e 00bf       nop          
00030e70 10058e70 a0d6       bvs          #0x10058db4
00030e72 10058e72 1e20       movs         r0, #0x1e
00030e74 10058e74 687d       ldrb         r0, [r5, #0x15]
00030e76 10058e76 7010       asrs         r0, r6, #1
00030e78 10058e78 30b5       push         {r4, r5, lr}
00030e7a 10058e7a 7d4b       ldr          r3, [pc, #0x1f4] ; literal raw=0x31070: 0x201eda28
00030e7c 10058e7c 83b0       sub          sp, #0xc
00030e7e 10058e7e 93f82455   ldrb.w       r5, [r3, #0x524]
00030e82 10058e82 7db9       cbnz         r5, #0x10058ea4
00030e84 10058e84 0446       mov          r4, r0
00030e86 10058e86 93f009fc   bl           #0x100ec69c
00030e8a 10058e8a 431e       subs         r3, r0, #1
00030e8c 10058e8c 0246       mov          r2, r0
00030e8e 10058e8e 0d2b       cmp          r3, #0xd
00030e90 10058e90 11d8       bhi          #0x10058eb6
00030e92 10058e92 dfe803f0   tbb          [pc, r3] ; literal raw=0x30e94: 0x427af003
00030e96 10058e96 7a42       rsbs         r2, r7, #0
00030e98 10058e98 1a1a       subs         r2, r3, r0
00030e9a 10058e9a 3528       cmp          r0, #0x35
00030e9c 10058e9c 5964       str          r1, [r3, #0x44]
00030e9e 10058e9e 6f10       asrs         r7, r5, #1
00030ea0 10058ea0 1010       asrs         r0, r2, #0x20
00030ea2 10058ea2 104e       ldr          r6, [pc, #0x40] ; literal raw=0x30ee4: 0x2c01e7e9
00030ea4 10058ea4 2d25       movs         r5, #0x2d
00030ea6 10058ea6 2d22       movs         r2, #0x2d
00030ea8 10058ea8 7249       ldr          r1, [pc, #0x1c8] ; literal raw=0x31074: 0x10707e04 [ENCO EQM] enco_audio_dyeq_get_eq_index, EQ_EXTRA_ID0:%d
00030eaa 10058eaa 4120       movs         r0, #0x41
00030eac 10058eac e7f02cfa   bl           #0x10140308
00030eb0 10058eb0 2846       mov          r0, r5
00030eb2 10058eb2 03b0       add          sp, #0xc
00030eb4 10058eb4 30bd       pop          {r4, r5, pc}
00030eb6 10058eb6 0823       movs         r3, #8
00030eb8 10058eb8 1d46       mov          r5, r3
00030eba 10058eba 6f49       ldr          r1, [pc, #0x1bc] ; literal raw=0x31078: 0x10707e40 [ENCO EQM] enco_audio_dyeq_get_eq_index, anc_mode: %d, get eq_index:%d from eq_id:%d
00030ebc 10058ebc 0094       str          r4, [sp]
00030ebe 10058ebe 4320       movs         r0, #0x43
00030ec0 10058ec0 e7f022fa   bl           #0x10140308
00030ec4 10058ec4 2846       mov          r0, r5
00030ec6 10058ec6 03b0       add          sp, #0xc
00030ec8 10058ec8 30bd       pop          {r4, r5, pc}
00030eca 10058eca 012c       cmp          r4, #1
00030ecc 10058ecc 00f08280   beq.w        #0x10058fd4
00030ed0 10058ed0 022c       cmp          r4, #2
00030ed2 10058ed2 6dd0       beq          #0x10058fb0
00030ed4 10058ed4 032c       cmp          r4, #3
00030ed6 10058ed6 00f0a480   beq.w        #0x10059022
00030eda 10058eda 072c       cmp          r4, #7
00030edc 10058edc 00f0bf80   beq.w        #0x1005905e
00030ee0 10058ee0 0223       movs         r3, #2
00030ee2 10058ee2 1d46       mov          r5, r3
00030ee4 10058ee4 e9e7       b            #0x10058eba
00030ee6 10058ee6 012c       cmp          r4, #1
00030ee8 10058ee8 7dd0       beq          #0x10058fe6
00030eea 10058eea 022c       cmp          r4, #2
00030eec 10058eec 5dd0       beq          #0x10058faa
00030eee 10058eee 032c       cmp          r4, #3
00030ef0 10058ef0 00f09480   beq.w        #0x1005901c
00030ef4 10058ef4 072c       cmp          r4, #7
00030ef6 10058ef6 00f0af80   beq.w        #0x10059058
00030efa 10058efa 0423       movs         r3, #4
00030efc 10058efc 1d46       mov          r5, r3
00030efe 10058efe dce7       b            #0x10058eba
00030f00 10058f00 012c       cmp          r4, #1
00030f02 10058f02 79d0       beq          #0x10058ff8
00030f04 10058f04 022c       cmp          r4, #2
00030f06 10058f06 4dd0       beq          #0x10058fa4
00030f08 10058f08 032c       cmp          r4, #3
00030f0a 10058f0a 00f09680   beq.w        #0x1005903a
00030f0e 10058f0e 072c       cmp          r4, #7
00030f10 10058f10 00f09980   beq.w        #0x10059046
00030f14 10058f14 0323       movs         r3, #3
00030f16 10058f16 1d46       mov          r5, r3
00030f18 10058f18 cfe7       b            #0x10058eba
00030f1a 10058f1a 012c       cmp          r4, #1
00030f1c 10058f1c 6fd0       beq          #0x10058ffe
00030f1e 10058f1e 022c       cmp          r4, #2
00030f20 10058f20 55d0       beq          #0x10058fce
00030f22 10058f22 032c       cmp          r4, #3
00030f24 10058f24 74d0       beq          #0x10059010
00030f26 10058f26 072c       cmp          r4, #7
00030f28 10058f28 00f09c80   beq.w        #0x10059064
00030f2c 10058f2c 0123       movs         r3, #1
00030f2e 10058f2e 1d46       mov          r5, r3
00030f30 10058f30 c3e7       b            #0x10058eba
00030f32 10058f32 012c       cmp          r4, #1
00030f34 10058f34 51d0       beq          #0x10058fda
00030f36 10058f36 022c       cmp          r4, #2
00030f38 10058f38 3dd0       beq          #0x10058fb6
00030f3a 10058f3a 032c       cmp          r4, #3
00030f3c 10058f3c 65d0       beq          #0x1005900a
00030f3e 10058f3e 072c       cmp          r4, #7
00030f40 10058f40 b9d1       bne          #0x10058eb6
00030f42 10058f42 2c23       movs         r3, #0x2c
00030f44 10058f44 1d46       mov          r5, r3
00030f46 10058f46 b8e7       b            #0x10058eba
00030f48 10058f48 012c       cmp          r4, #1
00030f4a 10058f4a 52d0       beq          #0x10058ff2
00030f4c 10058f4c 022c       cmp          r4, #2
00030f4e 10058f4e 3bd0       beq          #0x10058fc8
00030f50 10058f50 032c       cmp          r4, #3
00030f52 10058f52 6cd0       beq          #0x1005902e
00030f54 10058f54 072c       cmp          r4, #7
00030f56 10058f56 7cd0       beq          #0x10059052
00030f58 10058f58 0523       movs         r3, #5
00030f5a 10058f5a 1d46       mov          r5, r3
00030f5c 10058f5c ade7       b            #0x10058eba
00030f5e 10058f5e 012c       cmp          r4, #1
00030f60 10058f60 50d0       beq          #0x10059004
00030f62 10058f62 022c       cmp          r4, #2
00030f64 10058f64 1bd0       beq          #0x10058f9e
00030f66 10058f66 032c       cmp          r4, #3
00030f68 10058f68 55d0       beq          #0x10059016
00030f6a 10058f6a 072c       cmp          r4, #7
00030f6c 10058f6c 7dd0       beq          #0x1005906a
00030f6e 10058f6e 0723       movs         r3, #7
00030f70 10058f70 1d46       mov          r5, r3
00030f72 10058f72 a2e7       b            #0x10058eba
00030f74 10058f74 012c       cmp          r4, #1
00030f76 10058f76 39d0       beq          #0x10058fec
00030f78 10058f78 022c       cmp          r4, #2
00030f7a 10058f7a 22d0       beq          #0x10058fc2
00030f7c 10058f7c 032c       cmp          r4, #3
00030f7e 10058f7e 59d0       beq          #0x10059034
00030f80 10058f80 072c       cmp          r4, #7
00030f82 10058f82 5dd0       beq          #0x10059040
00030f84 10058f84 0623       movs         r3, #6
00030f86 10058f86 1d46       mov          r5, r3
00030f88 10058f88 97e7       b            #0x10058eba
00030f8a 10058f8a 012c       cmp          r4, #1
00030f8c 10058f8c 28d0       beq          #0x10058fe0
00030f8e 10058f8e 022c       cmp          r4, #2
00030f90 10058f90 14d0       beq          #0x10058fbc
00030f92 10058f92 032c       cmp          r4, #3
00030f94 10058f94 48d0       beq          #0x10059028
00030f96 10058f96 072c       cmp          r4, #7
00030f98 10058f98 58d0       beq          #0x1005904c
00030f9a 10058f9a 0023       movs         r3, #0
00030f9c 10058f9c 8de7       b            #0x10058eba
00030f9e 10058f9e 1923       movs         r3, #0x19
00030fa0 10058fa0 1d46       mov          r5, r3
00030fa2 10058fa2 8ae7       b            #0x10058eba
00030fa4 10058fa4 1523       movs         r3, #0x15
00030fa6 10058fa6 1d46       mov          r5, r3
00030fa8 10058fa8 87e7       b            #0x10058eba
00030faa 10058faa 1623       movs         r3, #0x16
00030fac 10058fac 1d46       mov          r5, r3
00030fae 10058fae 84e7       b            #0x10058eba
00030fb0 10058fb0 1423       movs         r3, #0x14
00030fb2 10058fb2 1d46       mov          r5, r3
00030fb4 10058fb4 81e7       b            #0x10058eba
00030fb6 10058fb6 1a23       movs         r3, #0x1a
00030fb8 10058fb8 1d46       mov          r5, r3
00030fba 10058fba 7ee7       b            #0x10058eba
00030fbc 10058fbc 1225       movs         r5, #0x12
00030fbe 10058fbe 2b46       mov          r3, r5
00030fc0 10058fc0 7be7       b            #0x10058eba
00030fc2 10058fc2 1823       movs         r3, #0x18
00030fc4 10058fc4 1d46       mov          r5, r3
00030fc6 10058fc6 78e7       b            #0x10058eba
00030fc8 10058fc8 1723       movs         r3, #0x17
00030fca 10058fca 1d46       mov          r5, r3
00030fcc 10058fcc 75e7       b            #0x10058eba
00030fce 10058fce 1323       movs         r3, #0x13
00030fd0 10058fd0 1d46       mov          r5, r3
00030fd2 10058fd2 72e7       b            #0x10058eba
00030fd4 10058fd4 0b23       movs         r3, #0xb
00030fd6 10058fd6 1d46       mov          r5, r3
00030fd8 10058fd8 6fe7       b            #0x10058eba
00030fda 10058fda 1123       movs         r3, #0x11
00030fdc 10058fdc 1d46       mov          r5, r3
00030fde 10058fde 6ce7       b            #0x10058eba
00030fe0 10058fe0 0925       movs         r5, #9
00030fe2 10058fe2 2b46       mov          r3, r5
00030fe4 10058fe4 69e7       b            #0x10058eba
00030fe6 10058fe6 0d23       movs         r3, #0xd
00030fe8 10058fe8 1d46       mov          r5, r3
00030fea 10058fea 66e7       b            #0x10058eba
00030fec 10058fec 0f23       movs         r3, #0xf
00030fee 10058fee 1d46       mov          r5, r3
00030ff0 10058ff0 63e7       b            #0x10058eba
00030ff2 10058ff2 0e23       movs         r3, #0xe
00030ff4 10058ff4 1d46       mov          r5, r3
00030ff6 10058ff6 60e7       b            #0x10058eba
00030ff8 10058ff8 0c23       movs         r3, #0xc
00030ffa 10058ffa 1d46       mov          r5, r3
00030ffc 10058ffc 5de7       b            #0x10058eba
00030ffe 10058ffe 0a23       movs         r3, #0xa
00031000 10059000 1d46       mov          r5, r3
00031002 10059002 5ae7       b            #0x10058eba
00031004 10059004 1023       movs         r3, #0x10
00031006 10059006 1d46       mov          r5, r3
00031008 10059008 57e7       b            #0x10058eba
0003100a 1005900a 2323       movs         r3, #0x23
0003100c 1005900c 1d46       mov          r5, r3
0003100e 1005900e 54e7       b            #0x10058eba
00031010 10059010 1c23       movs         r3, #0x1c
00031012 10059012 1d46       mov          r5, r3
00031014 10059014 51e7       b            #0x10058eba
00031016 10059016 2223       movs         r3, #0x22
00031018 10059018 1d46       mov          r5, r3
0003101a 1005901a 4ee7       b            #0x10058eba
0003101c 1005901c 1f23       movs         r3, #0x1f
0003101e 1005901e 1d46       mov          r5, r3
00031020 10059020 4be7       b            #0x10058eba
00031022 10059022 1d23       movs         r3, #0x1d
00031024 10059024 1d46       mov          r5, r3
00031026 10059026 48e7       b            #0x10058eba
00031028 10059028 1b25       movs         r5, #0x1b
0003102a 1005902a 2b46       mov          r3, r5
0003102c 1005902c 45e7       b            #0x10058eba
0003102e 1005902e 2023       movs         r3, #0x20
00031030 10059030 1d46       mov          r5, r3
00031032 10059032 42e7       b            #0x10058eba
00031034 10059034 2123       movs         r3, #0x21
00031036 10059036 1d46       mov          r5, r3
00031038 10059038 3fe7       b            #0x10058eba
0003103a 1005903a 1e23       movs         r3, #0x1e
0003103c 1005903c 1d46       mov          r5, r3
0003103e 1005903e 3ce7       b            #0x10058eba
00031040 10059040 2a23       movs         r3, #0x2a
00031042 10059042 1d46       mov          r5, r3
00031044 10059044 39e7       b            #0x10058eba
00031046 10059046 2723       movs         r3, #0x27
00031048 10059048 1d46       mov          r5, r3
0003104a 1005904a 36e7       b            #0x10058eba
0003104c 1005904c 2425       movs         r5, #0x24
0003104e 1005904e 2b46       mov          r3, r5
00031050 10059050 33e7       b            #0x10058eba
00031052 10059052 2923       movs         r3, #0x29
00031054 10059054 1d46       mov          r5, r3
00031056 10059056 30e7       b            #0x10058eba
00031058 10059058 2823       movs         r3, #0x28
0003105a 1005905a 1d46       mov          r5, r3
0003105c 1005905c 2de7       b            #0x10058eba
0003105e 1005905e 2623       movs         r3, #0x26
00031060 10059060 1d46       mov          r5, r3
00031062 10059062 2ae7       b            #0x10058eba
00031064 10059064 2523       movs         r3, #0x25
00031066 10059066 1d46       mov          r5, r3
00031068 10059068 27e7       b            #0x10058eba
0003106a 1005906a 2b23       movs         r3, #0x2b
0003106c 1005906c 1d46       mov          r5, r3
0003106e 1005906e 24e7       b            #0x10058eba
00031070 10059070 28da       bge          #0x100590c4
00031072 10059072 1e20       movs         r0, #0x1e
00031074 10059074 047e       ldrb         r4, [r0, #0x18]
00031076 10059076 7010       asrs         r0, r6, #1
00031078 10059078 407e       ldrb         r0, [r0, #0x19]
0003107a 1005907a 7010       asrs         r0, r6, #1
